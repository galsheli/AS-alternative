# Altshuler Shaham Alternative Investments – Investor Onboarding Portal

Hebrew/RTL, multi-step preliminary investor questionnaire (individual / corporate) with secure document upload,
branded PDF, e-mail delivery and private storage. Static front-end (no build step) + Netlify Functions.

## Deploy (Netlify)
1. Push this folder to a Git repo and connect it to Netlify (publish dir `public`, functions `netlify/functions` – already in `netlify.toml`).
2. Set environment variables (see `.env.example`). **Required:** `SUBMISSION_EMAIL`, `SESSION_SECRET`, `SMTP_*`, `MAIL_FROM`, `DEAL_NAME`, `INVESTMENT_CURRENCY`.
3. Deploy. Storage uses **Netlify Blobs** (private; no public URLs). The `purge` function runs daily for retention.

## Local
```
npm install
npm test                 # 25 end-to-end tests (validation, upload safety, PDF, e-mail, duplicates, resume…)
npm run dev              # http://localhost:8888 – local storage in .local/, e-mails written to .local/outbox/*.eml
```

## Configuration (no rebuild of the form architecture)
`config/site.config.mjs` + environment variables: deal name, currency, reference prefix, wording (intro, privacy note,
declaration, success), eligibility clauses (`ELIGIBILITY_OPTIONS_JSON`), required/optional fields (`FIELD_OVERRIDES_JSON`),
document requirements (`DOC_OVERRIDES_JSON`), W-9 later/now, upload limit, brand colours, resume expiry, retention.
Questionnaire structure: `public/js/schema.js` (shared by browser and server). All Hebrew text: `public/js/i18n/he.js`
(add `en.js` and switch it in `i18n/index.js` for English).

## Architecture
| Concern | Where |
|---|---|
| Fields, conditions, documents | `public/js/schema.js` |
| Validation (client **and** server) | `public/js/validators.js` |
| Review / PDF / e-mail summary | `public/js/summary.js` |
| API | `netlify/functions/{init,upload,submit,file,resume,purge}.mjs` |
| PDF (Hebrew bidi, Heebo font, logo) | `netlify/lib/pdf.mjs` (regenerate embedded assets: `node scripts/embed-assets.mjs`) |
| Separate stores | metadata / questionnaire data / PDFs / uploads / drafts (`netlify/lib/storage.mjs`) |

## Security summary
HTTPS + HSTS, strict CSP (no inline scripts/styles, no `innerHTML`), signed session token + custom header + same-origin check,
rate limits, honeypot + minimum fill time + optional Cloudflare Turnstile, server-side validation & sanitisation,
magic-byte file checks and PDF active-content rejection, random unguessable file IDs bound to the uploader's session,
signed expiring download links (default 7 days), AES-256-GCM encrypted drafts with hashed tokens in the URL fragment,
no localStorage of personal data, form values never logged, idempotent submissions (refresh-safe).

## Known limits / decisions to confirm
* Netlify Functions cap request bodies (~6MB): each file is uploaded separately, limit 4MB (`MAX_FILE_MB`); photos are auto-compressed in the browser, PDFs above the limit are rejected with a clear message.
* No antivirus engine runs on Netlify; add a scanning webhook/service if policy requires (hook point: `upload.mjs`).
* The logo was extracted from the letterhead in the supplied Word files (≈350px wide). Replace `public/assets/logo.png` (and run `embed-assets`) with the original vector/high-res logo.
* Eligibility clauses are not in the supplied material, so the field is free text until `ELIGIBILITY_OPTIONS_JSON` is set.
* Bank number, branch and SWIFT are optional by default (foreign accounts); override via `FIELD_OVERRIDES_JSON`.
* Privacy note default wording is neutral – have Legal review/replace (`TEXT_PRIVACY_NOTE`).
