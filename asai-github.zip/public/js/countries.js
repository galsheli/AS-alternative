// ISO 3166-1 alpha-2 codes. Names are resolved by the platform (Intl.DisplayNames),
// so Hebrew (or later English) names need no hand-maintained translation table.
export const COUNTRY_CODES = (
  'AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ ' +
  'CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR ' +
  'GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP ' +
  'KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT ' +
  'MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW ' +
  'SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG ' +
  'UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'
).split(' ');

const cache = {};
function displayNames(locale) {
  if (!cache[locale]) {
    try {
      cache[locale] = new Intl.DisplayNames([locale], { type: 'region' });
    } catch {
      cache[locale] = { of: (c) => c };
    }
  }
  return cache[locale];
}

export function countryName(code, locale = 'he') {
  if (!code) return '';
  try {
    return displayNames(locale).of(code) || code;
  } catch {
    return code;
  }
}

const PINNED = ['IL', 'US'];

/** Sorted options: [{code, name, search}], with Israel & USA pinned first. */
export function countryOptions(locale = 'he') {
  const list = COUNTRY_CODES.map((code) => {
    const name = countryName(code, locale);
    const en = countryName(code, 'en');
    return { code, name, search: (name + ' ' + en + ' ' + code).toLowerCase() };
  });
  list.sort((a, b) => a.name.localeCompare(b.name, locale));
  const pinned = PINNED.map((c) => list.find((x) => x.code === c)).filter(Boolean);
  return [...pinned, ...list.filter((x) => !PINNED.includes(x.code))];
}
