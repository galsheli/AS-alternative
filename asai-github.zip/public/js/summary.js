// Builds a language-neutral summary of a submission: used by the review screen,
// the branded PDF and the notification email, so all three always match.
import { t, locale } from './i18n/index.js';
import { SCHEMAS, wizardSteps, sectionVisible, fieldVisible, labelKeyOf, optionKeyOf, docsFor } from './schema.js';
import { countryName } from './countries.js';
import { isEmpty, parseAmount, normalizeIban } from './validators.js';

export function formatDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso || '';
}
export function formatAmount(v, currency) {
  const n = parseAmount(v);
  if (!Number.isFinite(n)) return String(v);
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(n) + (currency ? ' ' + currency : '');
}

export function formatValue(f, v, data, cfg) {
  if (isEmpty(v)) return '';
  switch (f.type) {
    case 'yesno':
      return v === 'yes' ? t('ui.yes') : v === 'no' ? t('ui.no') : '';
    case 'radio':
    case 'select':
      return t(optionKeyOf(f, v));
    case 'multicheck':
      return v.map((x) => t(optionKeyOf(f, x))).join(', ');
    case 'country':
      return countryName(v, 'he');
    case 'date':
      return formatDate(v);
    case 'amount':
      return formatAmount(v, cfg?.currency);
    case 'iban':
      return normalizeIban(v);
    case 'eligibility': {
      const o = (cfg?.eligibilityOptions || []).find((x) => x.value === v);
      return o ? o.label : String(v);
    }
    case 'signatorySelect': {
      const s = (data.signatories || [])[Number(v)];
      return s ? s.nameHe || s.nameEn || '' : '';
    }
    default:
      return String(v).trim();
  }
}

function rowsFor(fields, data, cfg, item) {
  const rows = [];
  const src = item || data;
  for (const f of fields) {
    if (!fieldVisible(f, data, cfg, item) || f.type === 'list') continue;
    const value = formatValue(f, src[f.id], data, cfg);
    if (value) rows.push({ id: f.id, label: t(labelKeyOf(f)), value, ltr: f.dir === 'ltr' });
  }
  return rows;
}

/**
 * @param {object} opts { includeEmpty: boolean } – review screen shows a "missing" marker for docs.
 * @returns [{key, title, stepIndex, blocks:[{title?, rows:[{label,value,ltr}]}]}]
 */
export function buildSummary(type, data, files, cfg, opts = {}) {
  const schema = SCHEMAS[type];
  const steps = wizardSteps(type);
  const out = [];
  const byKey = new Map();

  steps.forEach((step, stepIndex) => {
    if (step.kind !== 'form') return;
    for (const sec of step.def.sections) {
      if (!sectionVisible(sec, data, cfg)) continue;
      const key = sec.group || sec.id;
      let target = byKey.get(key);
      if (!target) {
        target = { key, title: t('s.' + key), stepIndex, blocks: [] };
        byKey.set(key, target);
        out.push(target);
      }
      const plainFields = sec.fields.filter((f) => f.type !== 'list');
      const rows = rowsFor(plainFields, data, cfg);
      if (rows.length) target.blocks.push({ title: sec.group && sec.id !== 'bankPayQ' ? t('s.' + sec.id) : undefined, rows });
      for (const lf of sec.fields.filter((f) => f.type === 'list')) {
        (data[lf.id] || []).forEach((item, i) => {
          const r = rowsFor(lf.fields, data, cfg, item || {});
          if (r.length) target.blocks.push({ title: t(lf.itemLabelKey, { n: i + 1 }), rows: r });
        });
      }
    }
  });

  const docStepIndex = steps.findIndex((s) => s.kind === 'docs');
  const docRows = [];
  for (const doc of docsFor(type, data, cfg)) {
    const list = (files?.[doc.id] || []).filter((f) => f.token || f.name);
    const names = list.map((f) => f.name).join('\n');
    if (names) docRows.push({ id: doc.id, label: t('d.' + doc.id), value: names, ltr: true, multiline: true });
    else if (opts.includeEmpty && doc.required) docRows.push({ id: doc.id, label: t('d.' + doc.id), value: t('ui.review.docsMissing'), missing: true });
  }
  if (docRows.length) out.push({ key: 'docs', title: t('s.docs'), stepIndex: docStepIndex, blocks: [{ rows: docRows }] });
  return out;
}
