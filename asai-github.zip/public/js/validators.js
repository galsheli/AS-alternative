// Shared validation. Returns i18n error keys (never technical messages).
import { SCHEMAS, wizardSteps, fieldVisible, sectionVisible, isRequired, docsFor } from './schema.js';
import { COUNTRY_CODES } from './countries.js';

const COUNTRY_SET = new Set(COUNTRY_CODES);
const EMAIL_RE = /^[^\s@<>()\[\]\\,;:"]+@[^\s@<>()\[\]\\,;:"]+\.[^\s@<>()\[\]\\,;:"]{2,}$/u;
const LATIN_RE = /^[\p{Script=Latin}\s.'’\-,]+$/u;

export const isEmpty = (v) =>
  v === undefined || v === null || (typeof v === 'string' && v.trim() === '') || (Array.isArray(v) && v.length === 0);

export function validEmail(v) {
  const s = String(v).trim();
  return s.length <= 254 && EMAIL_RE.test(s) && !s.includes('..');
}

export function validPhone(v) {
  const s = String(v).trim();
  if (!/^\+?[0-9\s\-().]{7,22}$/.test(s)) return false;
  const digits = s.replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

export function validDate(v, kind) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v));
  if (!m) return 'e.date';
  const [y, mo, da] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const dt = new Date(Date.UTC(y, mo - 1, da));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== da) return 'e.date';
  if (y < 1900) return 'e.date';
  if (kind === 'past' && dt.getTime() > Date.now() + 24 * 3600 * 1000) return 'e.dateFuture';
  return null;
}

export const parseAmount = (v) => Number(String(v).replace(/[,\s]/g, ''));
export function validAmount(v) {
  const n = parseAmount(v);
  return Number.isFinite(n) && n > 0 && n < 1e13;
}

export const normalizeIban = (v) => String(v).replace(/[\s-]/g, '').toUpperCase();
export function validIban(v) {
  const s = normalizeIban(v);
  if (!/^[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}$/.test(s)) return false;
  const rearranged = s.slice(4) + s.slice(0, 4);
  let num = '';
  for (const ch of rearranged) num += ch >= 'A' && ch <= 'Z' ? String(ch.charCodeAt(0) - 55) : ch;
  let rem = 0;
  for (const ch of num) rem = (rem * 10 + Number(ch)) % 97;
  return rem === 1;
}

export const validSwift = (v) => /^[A-Za-z]{6}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$/.test(String(v).replace(/\s/g, ''));

export function validIsraeliId(v) {
  const s = String(v).replace(/\D/g, '');
  if (s.length < 5 || s.length > 9 || String(v).trim() !== String(v).replace(/[^0-9]/g, '').trim()) return false;
  const id = s.padStart(9, '0');
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    let x = Number(id[i]) * (i % 2 === 0 ? 1 : 2);
    if (x > 9) x -= 9;
    sum += x;
  }
  return sum % 10 === 0;
}
export const validPassport = (v) => /^[\p{L}\p{N}][\p{L}\p{N}\s\-/]{3,28}$/u.test(String(v).trim());

// ---------- Field-level ----------
export function fieldError(f, value, ctx) {
  const { data, cfg, item, scope } = ctx;
  const required = isRequired(f, data, cfg, scope);
  const empty = isEmpty(value);
  if (empty) {
    if (!required) return null;
    return ['radio', 'yesno', 'select', 'country', 'signatorySelect', 'multicheck'].includes(f.type) ? 'e.choose' : 'e.required';
  }
  const s = typeof value === 'string' ? value.trim() : value;
  const max = f.maxLen || (f.type === 'textarea' ? 2000 : 200);
  if (typeof s === 'string' && s.length > max) return 'e.tooLong';

  switch (f.type) {
    case 'email':
      return validEmail(s) ? null : 'e.email';
    case 'tel':
      return validPhone(s) ? null : 'e.phone';
    case 'date':
      return validDate(s, f.dateKind);
    case 'amount':
      return validAmount(s) ? null : 'e.amount';
    case 'iban':
      return validIban(s) ? null : 'e.iban';
    case 'swift':
      return validSwift(s) ? null : 'e.swift';
    case 'country':
      return COUNTRY_SET.has(s) ? null : 'e.country';
    case 'radio':
    case 'select':
      return (f.options || []).includes(s) ? null : 'e.choose';
    case 'yesno':
      return s === 'yes' || s === 'no' ? null : 'e.choose';
    case 'multicheck':
      return Array.isArray(s) && s.every((x) => (f.options || []).includes(x)) ? null : 'e.choose';
    case 'signatorySelect': {
      const i = Number(s);
      return Number.isInteger(i) && i >= 0 && i < (data.signatories || []).length ? null : 'e.choose';
    }
    case 'eligibility': {
      const opts = cfg?.eligibilityOptions || [];
      if (opts.length) return opts.some((o) => o.value === s) ? null : 'e.choose';
      return null;
    }
    case 'idnumber': {
      if (data.idType === 'id') return validIsraeliId(s) ? null : 'e.israeliId';
      if (data.idType === 'passport') return validPassport(s) ? null : 'e.passport';
      return null;
    }
    case 'text':
      if (f.latin && !LATIN_RE.test(s)) return 'e.latin';
      if (f.idGeneric && !/^[\p{L}\p{N}][\p{L}\p{N}\s\-/]{3,28}$/u.test(s)) return 'e.idGeneric';
      return null;
    default:
      return null;
  }
}

function validateFieldList(fields, data, cfg, errors, opts = {}) {
  const { item, prefix = '', scope = '' } = opts;
  const src = item || data;
  for (const f of fields) {
    if (!fieldVisible(f, data, cfg, item)) continue;
    const key = prefix + f.id;
    if (f.type === 'list') {
      const arr = Array.isArray(data[f.id]) ? data[f.id] : [];
      if (arr.length < (f.min || 0)) errors[key] = 'e.min';
      arr.forEach((it, i) =>
        validateFieldList(f.fields, data, cfg, errors, { item: it || {}, prefix: `${f.id}.${i}.`, scope: f.id }),
      );
      continue;
    }
    const err = fieldError(f, src[f.id], { data, cfg, item, scope });
    if (err) errors[key] = err;
  }
}

/** Validate a single wizard step descriptor. Returns { key: i18nKey }. */
export function validateStep(type, step, data, files, cfg, declared) {
  const errors = {};
  if (step.kind === 'form') {
    for (const sec of step.def.sections) {
      if (!sectionVisible(sec, data, cfg)) continue;
      validateFieldList(sec.fields, data, cfg, errors);
    }
  } else if (step.kind === 'docs') {
    for (const doc of docsFor(type, data, cfg)) {
      const list = (files && files[doc.id]) || [];
      if (list.some((f) => f.status === 'uploading')) errors['doc.' + doc.id] = 'e.docUploading';
      else if (doc.required && !list.some((f) => f.token)) errors['doc.' + doc.id] = 'e.doc';
    }
  } else if (step.kind === 'review') {
    if (!declared) errors.declaration = 'e.declaration';
  }
  return errors;
}

/** Validate the entire submission. */
export function validateAll(type, data, files, cfg, declared = true) {
  const errors = {};
  if (!SCHEMAS[type]) return { ok: false, errors: { type: 'e.choose' }, firstStepIndex: 0 };
  let firstStepIndex = -1;
  wizardSteps(type).forEach((step, i) => {
    const e = validateStep(type, step, data, files, cfg, declared);
    if (Object.keys(e).length) {
      Object.assign(errors, e);
      if (firstStepIndex < 0) firstStepIndex = i;
    }
  });
  return { ok: Object.keys(errors).length === 0, errors, firstStepIndex };
}

// ---------- Upload helpers ----------
export const ALLOWED_EXT = ['pdf', 'jpg', 'jpeg', 'png'];
export const ALLOWED_MIME = ['application/pdf', 'image/jpeg', 'image/png'];
export const extOf = (name) => String(name).split('.').pop().toLowerCase();

export function fileTypeError(name, mime) {
  const ext = extOf(name);
  if (!ALLOWED_EXT.includes(ext)) return 'up.err.type';
  if (mime && !ALLOWED_MIME.includes(mime) && mime !== 'application/octet-stream') return 'up.err.type';
  return null;
}
