// Tiny DOM toolkit (no innerHTML anywhere => no XSS surface) + icons + reusable widgets.
import { t, locale } from './i18n/index.js';
import { countryOptions, countryName } from './countries.js';

const SVGNS = 'http://www.w3.org/2000/svg';

export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'required' || k === 'multiple' || k === 'hidden') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
}
export const clear = (el) => {
  while (el.firstChild) el.removeChild(el.firstChild);
  return el;
};

const ICONS = {
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  building: '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>',
  upload: '<path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m16 16-4-4-4 4"/>',
  camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  file: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  pencil: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
  alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  arrowLeft: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  arrowRight: '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  copy: '<rect x="8" y="8" width="14" height="14" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  bookmark: '<path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
};
export function icon(name, size = 20, cls = '') {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('width', size);
  s.setAttribute('height', size);
  s.setAttribute('fill', 'none');
  s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '1.75');
  s.setAttribute('stroke-linecap', 'round');
  s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  s.setAttribute('focusable', 'false');
  if (cls) s.setAttribute('class', cls);
  // static, trusted path data only
  const tpl = new DOMParser().parseFromString(`<svg xmlns="${SVGNS}">${ICONS[name] || ''}</svg>`, 'image/svg+xml');
  for (const n of Array.from(tpl.documentElement.childNodes)) s.appendChild(document.importNode(n, true));
  return s;
}

// ---------- Number formatting ----------
export function formatThousands(raw) {
  const s = String(raw).replace(/[^\d.]/g, '');
  const [i, d] = s.split('.');
  const int = i.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return d !== undefined ? `${int}.${d.slice(0, 2)}` : int;
}

// ---------- Field shell ----------
let uid = 0;
export function fieldShell({ id, label, hint, required, wide, error, control, group, extraClass = '' }) {
  const eid = id + '-err';
  const hid = id + '-hint';
  const wrap = h(
    'div',
    { class: `field ${wide ? 'field--wide' : ''} ${error ? 'has-error' : ''} ${extraClass}`, dataset: { fieldKey: id } },
    (group ? h('div', { class: 'field__label', id: id + '-lbl' }, label, required === false ? h('span', { class: 'field__opt' }, t('ui.optional')) : null)
      : h('label', { class: 'field__label', for: id, id: id + '-lbl' }, label, required === false ? h('span', { class: 'field__opt' }, t('ui.optional')) : null)),
    control,
    hint ? h('div', { class: 'field__hint', id: hid }, hint) : null,
    h('div', { class: 'field__error', id: eid, role: error ? 'alert' : null }, error ? [icon('alert', 15), h('span', {}, error)] : null),
  );
  return wrap;
}
export function describe(input, id, hasHint, hasError) {
  const ids = [hasHint ? id + '-hint' : '', id + '-err'].filter(Boolean).join(' ');
  input.setAttribute('aria-describedby', ids);
  if (hasError) input.setAttribute('aria-invalid', 'true');
}

// ---------- Segmented choice (yes/no, radio) ----------
export function choiceGroup({ id, name, options, value, onChange, error, compact }) {
  const wrap = h('div', { class: `choice ${compact ? 'choice--row' : ''}`, role: 'radiogroup', 'aria-labelledby': id + '-lbl', id });
  options.forEach((o, i) => {
    const iid = `${id}-${i}`;
    const input = h('input', {
      type: 'radio', name, id: iid, value: o.value, checked: value === o.value,
      dataset: { key: name },
      onChange: () => onChange(o.value),
    });
    wrap.append(h('label', { class: 'choice__item', for: iid }, input, h('span', { class: 'choice__dot', 'aria-hidden': 'true' }), h('span', { class: 'choice__text' }, o.label)));
  });
  return wrap;
}

export function checkGroup({ id, options, values, onChange }) {
  const wrap = h('div', { class: 'choice choice--check', role: 'group', 'aria-labelledby': id + '-lbl', id });
  options.forEach((o, i) => {
    const iid = `${id}-${i}`;
    const input = h('input', {
      type: 'checkbox', id: iid, value: o.value, checked: values.includes(o.value), dataset: { key: id },
      onChange: (e) => {
        const set = new Set(values);
        e.target.checked ? set.add(o.value) : set.delete(o.value);
        onChange(options.map((x) => x.value).filter((v) => set.has(v)));
      },
    });
    wrap.append(h('label', { class: 'choice__item', for: iid }, input, h('span', { class: 'choice__box', 'aria-hidden': 'true' }, icon('check', 14)), h('span', { class: 'choice__text' }, o.label)));
  });
  return wrap;
}

// ---------- Searchable country combobox (accessible: ARIA 1.2 combobox + listbox) ----------
let COUNTRIES;
export function countryCombobox({ id, value, onChange, invalid, autocomplete }) {
  COUNTRIES ||= countryOptions('he');
  const listId = id + '-list';
  const input = h('input', {
    id, type: 'text', class: 'input', role: 'combobox', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false',
    'aria-autocomplete': 'list', 'aria-expanded': 'false', 'aria-controls': listId, placeholder: t('ui.searchCountry'),
    value: countryName(value), dataset: { key: id }, enterkeyhint: 'done',
  });
  const list = h('ul', { class: 'combo__list', id: listId, role: 'listbox', hidden: true });
  const wrap = h('div', { class: 'combo' }, input, h('span', { class: 'combo__chev', 'aria-hidden': 'true' }, icon('chevron', 18)), list);
  let items = [];
  let active = -1;
  let current = value || '';

  const norm = (s) => s.toLowerCase().trim();
  function render(q) {
    const n = norm(q);
    items = (n ? COUNTRIES.filter((c) => c.search.includes(n)) : COUNTRIES).slice(0, 80);
    clear(list);
    if (!items.length) list.append(h('li', { class: 'combo__empty', role: 'presentation' }, t('ui.noResults')));
    items.forEach((c, i) =>
      list.append(
        h('li', {
          role: 'option', id: `${id}-opt-${i}`, class: 'combo__opt', 'aria-selected': String(c.code === current),
          onMousedown: (e) => { e.preventDefault(); choose(c); },
        }, c.name),
      ),
    );
    active = items.length ? 0 : -1;
    mark();
  }
  function mark() {
    Array.from(list.querySelectorAll('[role=option]')).forEach((o, i) => o.classList.toggle('is-active', i === active));
    if (active >= 0) {
      input.setAttribute('aria-activedescendant', `${id}-opt-${active}`);
      list.querySelector(`#${CSS.escape(id + '-opt-' + active)}`)?.scrollIntoView({ block: 'nearest' });
    } else input.removeAttribute('aria-activedescendant');
  }
  function open() { list.hidden = false; input.setAttribute('aria-expanded', 'true'); }
  function close() { list.hidden = true; input.setAttribute('aria-expanded', 'false'); }
  function choose(c) {
    current = c.code;
    input.value = c.name;
    close();
    onChange(c.code);
  }
  input.addEventListener('focus', () => { input.select(); render(''); open(); });
  input.addEventListener('input', () => { render(input.value); open(); if (!input.value) { current = ''; onChange(''); } });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); if (list.hidden) { render(input.value); open(); } else { active = Math.min(items.length - 1, active + 1); mark(); } }
    else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(0, active - 1); mark(); }
    else if (e.key === 'Enter' && !list.hidden && active >= 0) { e.preventDefault(); choose(items[active]); }
    else if (e.key === 'Escape') { close(); input.value = countryName(current); }
  });
  input.addEventListener('blur', () => {
    setTimeout(() => {
      close();
      const exact = COUNTRIES.find((c) => norm(c.name) === norm(input.value));
      if (exact) { if (exact.code !== current) { current = exact.code; onChange(current); } input.value = exact.name; }
      else input.value = countryName(current);
    }, 0);
  });
  return { wrap, input };
}

// ---------- Toast-ish live region ----------
export function announce(msg) {
  const el = document.getElementById('live');
  if (!el) return;
  el.textContent = '';
  setTimeout(() => (el.textContent = msg), 30);
}

export { t, locale };
