import he from './he.js';

// Single place to switch language later (e.g. import en from './en.js').
const dict = he;

export const dir = dict.dir;
export const lang = dict.lang;
export const locale = dict.locale;

/** Translate a key. Supports {placeholders}. Unknown keys return the key itself. */
export function t(key, vars) {
  let s = dict[key];
  if (s === undefined) return key;
  if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
  return s;
}
export const has = (key) => dict[key] !== undefined;
