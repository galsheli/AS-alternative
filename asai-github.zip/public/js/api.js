// Thin API client. Session token lives in memory only.
let session = '';
export const setSession = (s) => (session = s);
export const getSession = () => session;

async function call(path, opts = {}, retry = true) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'x-asai-session': session, ...(opts.headers || {}) },
    credentials: 'same-origin',
    cache: 'no-store',
  });
  let body = null;
  try { body = await res.json(); } catch {}
  if (res.status === 401 && retry) {
    const init = await init_();
    if (init?.session) return call(path, opts, false);
  }
  return { status: res.status, ok: res.ok && body?.ok !== false, body: body || {} };
}

export async function init_() {
  const res = await fetch('/api/init', { cache: 'no-store', credentials: 'same-origin' });
  let j = null;
  try { j = await res.json(); } catch {}
  if (!res.ok || !j?.ok) throw Object.assign(new Error('init'), { status: res.status, code: j?.error || 'no_json' });
  session = j.session;
  return j;
}

export const postJSON = (path, payload) =>
  call(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });

/** Upload one file with progress. Resolves { ok, status, body }. */
export function uploadFile(blob, name, docId, onProgress) {
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `/api/upload?doc=${encodeURIComponent(docId)}&name=${encodeURIComponent(name)}`);
    xhr.setRequestHeader('x-asai-session', session);
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      let body = {};
      try { body = JSON.parse(xhr.responseText); } catch {}
      resolve({ ok: xhr.status === 200 && body.ok, status: xhr.status, body });
    };
    xhr.onerror = () => resolve({ ok: false, status: 0, body: {} });
    xhr.ontimeout = () => resolve({ ok: false, status: 0, body: {} });
    xhr.timeout = 120000;
    xhr.send(blob);
  });
}
