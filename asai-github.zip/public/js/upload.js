import { h, clear, icon, t, announce } from './ui.js';
import { uploadFile } from './api.js';
import { fileTypeError, extOf } from './validators.js';

const MB = 1024 * 1024;
const MAX_DIM = 2400;
const fmtSize = (n) => (n >= MB ? (n / MB).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
let lid = 0;

/** Validates, and (for photos) downsizes + strips EXIF so phone pictures always fit the upload limit. */
async function prepare(file, maxBytes) {
  const typeErr = fileTypeError(file.name, file.type);
  if (typeErr) return { error: typeErr };
  if (file.size === 0) return { error: 'up.err.empty' };
  const ext = extOf(file.name);
  const isImage = ext !== 'pdf';
  if (!isImage) return file.size > maxBytes ? { error: 'up.err.size' } : { blob: file, name: file.name };

  const probe = await bitmap(file).catch(() => null);
  if (probe) {
    const small = Math.max(probe.width, probe.height) <= MAX_DIM && file.size <= 1.5 * MB;
    probe.close?.();
    if (small) return { blob: file, name: file.name };
  } else if (file.size <= maxBytes) return { blob: file, name: file.name };
  try {
    const bmp = await bitmap(file);
    let scale = Math.min(1, MAX_DIM / Math.max(bmp.width, bmp.height));
    let quality = 0.86;
    for (let attempt = 0; attempt < 6; attempt++) {
      const w = Math.round(bmp.width * scale);
      const hgt = Math.round(bmp.height * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = hgt;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, w, hgt);
      ctx.drawImage(bmp, 0, 0, w, hgt);
      const blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', quality));
      if (blob && blob.size <= maxBytes) {
        bmp.close?.();
        return { blob, name: file.name.replace(/\.[^.]+$/, '') + '.jpg' };
      }
      quality = Math.max(0.5, quality - 0.1);
      scale *= 0.85;
    }
    bmp.close?.();
    return { error: 'up.err.size' };
  } catch {
    return file.size > maxBytes ? { error: 'up.err.size' } : { blob: file, name: file.name };
  }
}
function bitmap(file) {
  return typeof createImageBitmap === 'function'
    ? createImageBitmap(file, { imageOrientation: 'from-image' }).catch(() => createImageBitmap(file))
    : Promise.reject(new Error('unsupported'));
}

export function createUploader(ctx) {
  // ctx: { files (state map), cfg, onChange(), rerender(docId) }
  const maxBytes = () => Math.min(ctx.cfg.maxFileMB || 4, 4.5) * MB;

  async function addFiles(doc, fileList, replaceId) {
    const list = ctx.files[doc.id] || (ctx.files[doc.id] = []);
    let incoming = Array.from(fileList);
    if (replaceId) incoming = incoming.slice(0, 1);
    const room = replaceId ? 1 : doc.max - list.filter((f) => f.status !== 'error').length;
    if (!replaceId && incoming.length > room) {
      incoming = incoming.slice(0, Math.max(0, room));
      ctx.setError(doc.id, t('up.err.max', { n: doc.max }));
    } else ctx.setError(doc.id, '');
    for (const file of incoming) {
      const entry = { lid: ++lid, name: file.name, size: file.size, status: 'preparing', progress: 0 };
      if (replaceId) {
        const i = list.findIndex((f) => f.lid === replaceId);
        if (i >= 0) list[i] = entry; else list.push(entry);
      } else list.push(entry);
      ctx.rerender(doc.id);
      await process(doc, entry, file);
    }
  }

  async function process(doc, entry, file) {
    const prep = await prepare(file, maxBytes());
    if (prep.error) {
      entry.status = 'error';
      entry.error = t(prep.error, { mb: ctx.cfg.maxFileMB });
      ctx.rerender(doc.id);
      return;
    }
    entry.blob = prep.blob;
    entry.name = prep.name;
    entry.size = prep.blob.size;
    entry.status = 'uploading';
    ctx.rerender(doc.id);
    const res = await uploadFile(prep.blob, prep.name, doc.id, (p) => {
      entry.progress = p;
      ctx.progress(doc.id, entry);
    });
    if (res.ok) {
      Object.assign(entry, { token: res.body.token, name: res.body.name, size: res.body.size, type: res.body.type, status: 'done', progress: 100 });
      delete entry.blob;
      ctx.setError(doc.id, '');
      announce(t('up.status.ok'));
    } else {
      entry.status = 'error';
      const base = res.status === 415 || res.status === 422 ? t('up.err.rejected') : res.status === 413 ? t('up.err.size', { mb: ctx.cfg.maxFileMB }) : res.status === 429 ? t('fail.rate') : res.status === 401 ? t('fail.session') : t('up.err.failed');
      // small non-sensitive diagnostic code (HTTP status / error code) for support
      entry.error = `${base} (${res.status || 'net'}/${res.body?.error || 'no_response'})`;
    }
    ctx.rerender(doc.id);
    ctx.onChange();
  }

  function retry(doc, entry) {
    if (!entry.blob) return;
    entry.status = 'uploading';
    entry.progress = 0;
    ctx.rerender(doc.id);
    process(doc, entry, entry.blob);
  }

  function remove(doc, entry) {
    const list = ctx.files[doc.id] || [];
    ctx.files[doc.id] = list.filter((f) => f.lid !== entry.lid);
    ctx.rerender(doc.id);
    ctx.onChange();
  }

  /** Builds the card for one document requirement. */
  function card(doc, error) {
    const list = ctx.files[doc.id] || [];
    const done = list.some((f) => f.status === 'done');
    const status = done ? 'ok' : doc.required ? 'missing' : 'optional';
    const canAdd = list.filter((f) => f.status !== 'error').length < doc.max;
    const inputId = `up-${doc.id}`;
    const multiple = doc.max > 1;
    const accept = '.pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png';

    const fileInput = h('input', { type: 'file', id: inputId, class: 'sr-only', accept, multiple, onChange: (e) => { addFiles(doc, e.target.files); e.target.value = ''; } });
    const camInput = h('input', { type: 'file', id: inputId + '-cam', class: 'sr-only', accept: 'image/*', capture: 'environment', onChange: (e) => { addFiles(doc, e.target.files); e.target.value = ''; } });

    const zone = h('div', { class: 'drop', dataset: { docDrop: doc.id } },
      h('div', { class: 'drop__icon' }, icon('upload', 26)),
      h('div', { class: 'drop__text' }, h('span', { class: 'drop__drag' }, t('up.drop') + ' '), h('label', { class: 'link-btn', for: inputId, tabindex: '0', role: 'button', onKeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } } }, t('up.browse'))),
      h('div', { class: 'drop__actions' },
        h('label', { class: 'btn btn--secondary btn--sm', for: inputId, tabindex: '-1' }, icon('upload', 16), t('up.browse')),
        h('label', { class: 'btn btn--secondary btn--sm drop__cam', for: inputId + '-cam', tabindex: '0', role: 'button', onKeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); camInput.click(); } } }, icon('camera', 16), t('up.camera'))),
      h('div', { class: 'drop__fmt' }, t('up.formats', { mb: ctx.cfg.maxFileMB })),
      fileInput, camInput,
    );
    ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add('is-over'); }));
    ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove('is-over'); }));
    zone.addEventListener('drop', (e) => { if (e.dataTransfer?.files?.length) addFiles(doc, e.dataTransfer.files); });

    const fileRows = list.map((f) => {
      const rid = `${inputId}-r${f.lid}`;
      const repl = h('input', { type: 'file', id: rid, class: 'sr-only', accept, onChange: (e) => { addFiles(doc, e.target.files, f.lid); e.target.value = ''; } });
      const bar = f.status === 'uploading' || f.status === 'preparing'
        ? h('div', { class: 'file__bar', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(f.progress || 0), 'aria-label': t('up.uploading') }, h('span', { dataset: { pct: f.lid } }))
        : null;
      const el = h('li', { class: `file file--${f.status}`, dataset: { lid: f.lid } },
        h('div', { class: 'file__icon' }, icon(f.status === 'done' ? 'check' : f.status === 'error' ? 'alert' : 'file', 18)),
        h('div', { class: 'file__meta' },
          h('div', { class: 'file__name', dir: 'auto' }, f.name),
          h('div', { class: 'file__sub' }, f.status === 'preparing' ? t('up.preparing') : f.status === 'uploading' ? `${t('up.uploading')} ${f.progress || 0}%` : f.status === 'error' ? f.error : fmtSize(f.size)),
          bar),
        h('div', { class: 'file__actions' },
          f.status === 'error' && f.blob ? h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('up.retry'), title: t('up.retry'), onClick: () => retry(doc, f) }, icon('refresh', 18)) : null,
          f.status === 'done' || f.status === 'error' ? h('label', { class: 'icon-btn', for: rid, title: t('up.replace'), role: 'button', tabindex: '0', 'aria-label': t('up.replace'), onKeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); repl.click(); } } }, icon('refresh', 18)) : null,
          h('button', { type: 'button', class: 'icon-btn icon-btn--danger', 'aria-label': t('up.delete'), title: t('up.delete'), onClick: () => remove(doc, f) }, icon('trash', 18)),
          repl),
      );
      return el;
    });

    return h('section', { class: `doc doc--${status}`, id: `doc-${doc.id}`, dataset: { fieldKey: 'doc.' + doc.id }, 'aria-labelledby': `doc-${doc.id}-t` },
      h('div', { class: 'doc__head' },
        h('h3', { class: 'doc__title', id: `doc-${doc.id}-t` }, t('d.' + doc.id)),
        h('span', { class: `badge badge--${status}` }, status === 'ok' ? icon('check', 13) : null, t('up.status.' + status))),
      h('p', { class: 'doc__instr' }, t(doc.instr)),
      fileRows.length ? h('ul', { class: 'files' }, fileRows) : null,
      canAdd ? zone : null,
      h('div', { class: 'field__error', role: error ? 'alert' : null }, error ? [icon('alert', 15), h('span', {}, error)] : null),
    );
  }
  return { card, addFiles };
}
