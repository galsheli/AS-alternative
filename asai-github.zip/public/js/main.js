import { t, lang, dir } from './i18n/index.js';
import { h, clear, icon, fieldShell, describe, choiceGroup, checkGroup, countryCombobox, formatThousands, announce } from './ui.js';
import { SCHEMAS, wizardSteps, initialData, fieldVisible, sectionVisible, labelKeyOf, optionKeyOf, docsFor, isRequired } from './schema.js';
import { fieldError, validateStep, validateAll } from './validators.js';
import { buildSummary } from './summary.js';
import { init_, setSession, postJSON } from './api.js';
import { createUploader } from './upload.js';

const $app = document.getElementById('app');
document.documentElement.lang = lang;
document.documentElement.dir = dir;

const randKey = () => btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(24)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');

const state = {
  cfg: null,
  i: 0, // 0 intro · 1 investor type · 2.. wizard steps · 'success'
  type: '',
  data: {},
  files: {},
  errors: {},
  uploadErr: {},
  declared: false,
  key: randKey(),
  submitting: false,
  dirty: false,
  fromReview: false,
  banner: '',
  ref: '',
  sig: '',
  turnstile: '',
};

const steps = () => wizardSteps(state.type);
const cfgText = (name, key) => state.cfg?.texts?.[name] || t(key);
const doneFiles = () => Object.fromEntries(Object.entries(state.files).map(([k, l]) => [k, l.filter((f) => f.status === 'done')]));

// =====================================================================================
// Navigation
// =====================================================================================
function go(i, { push = true, scrollTo = '' } = {}) {
  if (typeof i === 'number' && i > 1 && !state.type) i = 1;
  state.i = i;
  state.banner = '';
  if (push) history.pushState({ i }, '');
  render();
  window.scrollTo(0, 0);
  const target = scrollTo && document.getElementById(scrollTo);
  if (target) target.scrollIntoView({ block: 'start' });
  else document.getElementById('heading')?.focus({ preventScroll: true });
  const total = state.type ? steps().length + 1 : 0;
  if (typeof i === 'number' && i >= 1) announce(document.getElementById('heading')?.textContent || '');
  void total;
}
window.addEventListener('popstate', (e) => {
  if (state.i === 'success' || state.submitting) return;
  if (e.state && e.state.i !== undefined) go(e.state.i, { push: false });
});
window.addEventListener('beforeunload', (e) => {
  if (state.dirty && state.i !== 'success' && !state.submitting) {
    e.preventDefault();
    e.returnValue = '';
  }
});

// =====================================================================================
// Shell pieces
// =====================================================================================
function topbar() {
  const c = state.cfg;
  return h('header', { class: 'topbar' },
    h('div', { class: 'topbar__in' },
      h('img', { class: 'topbar__logo', src: c.brand.logo, alt: c.brand.name, width: 44, height: 47 }),
      h('div', { class: 'topbar__deal' }, h('span', { class: 'chip' }, t('ui.deal', { deal: c.dealName }))),
    ));
}

function progressHead(titleKey, n, total) {
  const pct = Math.round((n / total) * 100);
  const bar = h('div', { class: 'progress', role: 'progressbar', 'aria-label': t('ui.progress'), 'aria-valuemin': '1', 'aria-valuemax': String(total), 'aria-valuenow': String(n) }, h('span', {}));
  bar.firstChild.style.width = pct + '%';
  return h('div', { class: 'stephead' },
    h('div', { class: 'stephead__meta' }, h('span', { class: 'eyebrow' }, t('ui.stepOf', { n, total })), h('span', { class: 'lock' }, icon('lock', 14), t('ui.footerSecure'))),
    h('h1', { class: 'stephead__title', id: 'heading', tabindex: '-1' }, t(titleKey)),
    bar);
}

function navBar({ onBack, onNext, nextLabel, nextIcon = true, showSave = true, disabled = false }) {
  return h('div', { class: 'navbar' },
    h('div', { class: 'navbar__in' },
      h('button', { type: 'button', class: 'btn btn--ghost', onClick: onBack, disabled: state.submitting }, icon('arrowRight', 18), t('ui.back')),
      h('div', { class: 'navbar__spacer' }),
      showSave && state.cfg.enableResume ? h('button', { type: 'button', class: 'btn btn--secondary navbar__save', onClick: saveDraft, disabled: state.submitting }, icon('bookmark', 18), t('ui.saveContinue')) : null,
      h('button', { type: 'button', class: 'btn btn--primary', id: 'next-btn', onClick: onNext, disabled: disabled || state.submitting }, nextLabel, nextIcon ? icon('arrowLeft', 18) : null),
    ));
}

// =====================================================================================
// Screens
// =====================================================================================
function render() {
  clear($app);
  const c = state.cfg;
  if (!c) return;
  let screen;
  if (state.i === 0) screen = introScreen();
  else if (state.i === 'success') screen = successScreen();
  else if (state.i === 1) screen = typeScreen();
  else {
    const step = steps()[state.i - 2];
    if (!step) return go(1, { push: false });
    screen = step.kind === 'form' ? formScreen(step) : step.kind === 'docs' ? docsScreen(step) : reviewScreen(step);
  }
  const showTop = state.i !== 0 && state.i !== 'success';
  if (showTop) $app.append(topbar());
  $app.append(screen);
}

function introScreen() {
  const c = state.cfg;
  return h('main', { class: 'hero' },
    h('img', { class: 'hero__mark', src: c.brand.logoMark, alt: '', 'aria-hidden': 'true' }),
    h('div', { class: 'hero__card' },
      h('img', { class: 'hero__logo', src: c.brand.logo, alt: c.brand.name, width: 128, height: 137 }),
      h('p', { class: 'eyebrow eyebrow--center' }, t('intro.eyebrow')),
      h('h1', { class: 'hero__title', id: 'heading', tabindex: '-1' }, cfgText('introTitle', 'intro.title')),
      h('p', { class: 'hero__lead' }, cfgText('introLead', 'intro.lead')),
      h('div', { class: 'chip chip--lg' }, t('ui.deal', { deal: c.dealName })),
      h('div', { class: 'note note--privacy' }, icon('shield', 20), h('div', {}, h('strong', {}, t('ui.privacyTitle')), h('p', {}, cfgText('privacyNote', 'intro.privacy')))),
      h('button', { type: 'button', class: 'btn btn--primary btn--lg', onClick: () => go(1) }, t('ui.start'), icon('arrowLeft', 20)),
    ),
    h('p', { class: 'hero__foot' }, icon('lock', 14), t('ui.footerSecure')));
}

function typeScreen() {
  const cards = ['individual', 'corporate'].map((v) => {
    const id = 'type-' + v;
    const input = h('input', { type: 'radio', name: 'investorType', id, value: v, class: 'sr-only', checked: state.type === v, onChange: () => selectType(v) });
    return h('label', { class: `typecard ${state.type === v ? 'is-selected' : ''}`, for: id },
      input,
      h('span', { class: 'typecard__icon' }, icon(v === 'individual' ? 'user' : 'building', 34)),
      h('span', { class: 'typecard__title' }, t('type.' + v)),
      h('span', { class: 'typecard__check', 'aria-hidden': 'true' }, icon('check', 16)));
  });
  return h('main', { class: 'stage' },
    h('div', { class: 'stephead' },
      h('div', { class: 'stephead__meta' }, h('span', { class: 'eyebrow' }, t('ui.stepOf', { n: 1, total: state.type ? steps().length + 1 : 7 })), h('span', { class: 'lock' }, icon('lock', 14), t('ui.footerSecure'))),
      h('h1', { class: 'stephead__title', id: 'heading', tabindex: '-1' }, t('type.title')),
      h('p', { class: 'stephead__lead' }, t('type.lead'))),
    h('div', { class: 'typecards', role: 'radiogroup', 'aria-label': t('type.title') }, cards),
    h('div', { class: 'field__error', id: 'type-err' }),
    navBar({ onBack: () => go(0), onNext: () => (state.type ? go(2) : typeError()), nextLabel: t('ui.next'), showSave: false }));
}
function typeError() {
  const e = document.getElementById('type-err');
  clear(e);
  e.append(icon('alert', 15), h('span', {}, t('e.choose')));
  e.setAttribute('role', 'alert');
}
function selectType(v) {
  if (state.type && state.type !== v && state.dirty && !window.confirm(t('type.switchConfirm'))) {
    render();
    return;
  }
  if (state.type !== v) {
    state.type = v;
    state.data = initialData(v);
    state.files = {};
    state.errors = {};
    state.declared = false;
    state.dirty = false;
  }
  render();
  document.getElementById('next-btn')?.focus();
}

// ---------------------------------------------------------------- Form steps
function formScreen(step) {
  const list = steps();
  const body = h('div', { class: 'sections', id: 'step-body' });
  const screen = h('main', { class: 'stage' }, progressHead(step.titleKey, state.i, list.length + 1), body, navBar(navHandlers()));
  fillBody(body, step);
  return screen;
}

function navHandlers() {
  const last = steps().length + 1;
  const isBeforeReview = state.i === last - 1;
  return {
    onBack: () => go(state.i - 1),
    onNext: next,
    nextLabel: state.fromReview ? t('ui.backToReview') : isBeforeReview ? t('ui.next') : t('ui.next'),
  };
}

function next() {
  const list = steps();
  const step = list[state.i - 2];
  const errs = validateStep(state.type, step, state.data, state.files, state.cfg, state.declared);
  state.errors = errs;
  const keys = Object.keys(errs);
  if (keys.length) {
    if (step.kind === 'form') rebuildBody(step);
    else if (step.kind === 'docs') rebuildDocs();
    const first = document.querySelector('.has-error, .doc--has-error');
    first?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    (first?.querySelector('input:not([type=radio]):not([type=checkbox]):not(.sr-only),select,textarea,input[type=radio],input[type=checkbox]'))?.focus({ preventScroll: true });
    announce(t('ui.errorsSummary', { n: keys.length }));
    return;
  }
  if (state.fromReview) {
    state.fromReview = false;
    return go(list.length + 1);
  }
  go(state.i + 1);
}

function fillBody(body, step) {
  clear(body);
  const d = state.data;
  const cfg = state.cfg;
  const seen = new Set();
  for (const sec of step.def.sections) {
    if (!sectionVisible(sec, d, cfg)) continue;
    const gk = sec.group || sec.id;
    const secTitle = t('s.' + sec.id);
    const showTitle = sec.id !== 'bankPayQ' && (step.def.sections.length > 1 || secTitle !== t(step.titleKey));
    const node = h('section', { class: 'card', id: seen.has(gk) ? null : 'sec-' + gk, 'aria-label': secTitle },
      showTitle ? h('h2', { class: 'card__title' }, secTitle) : null,
      sec.noteKey ? h('div', { class: 'note' }, icon('file', 18), h('p', {}, t(sec.noteKey))) : null,
      h('div', { class: 'grid' }, sec.fields.filter((f) => fieldVisible(f, d, cfg)).map((f) => (f.type === 'list' ? renderList(f) : renderField(f, { src: d, prefix: '', scope: '', item: undefined })))));
    seen.add(gk);
    body.append(node);
  }
  state.sig = visSig(step);
}

function visSig(step) {
  const d = state.data;
  const cfg = state.cfg;
  const parts = [];
  for (const sec of step.def.sections) {
    if (!sectionVisible(sec, d, cfg)) continue;
    parts.push(sec.id);
    for (const f of sec.fields) {
      if (!fieldVisible(f, d, cfg)) continue;
      parts.push(f.id);
      if (f.depsKey) parts.push(f.depsKey(d));
      if (f.type === 'list') (d[f.id] || []).forEach((it, i) => f.fields.forEach((sf) => fieldVisible(sf, d, cfg, it || {}) && parts.push(`${f.id}${i}${sf.id}`)));
    }
  }
  return parts.join('|');
}

function rebuildBody(step) {
  const body = document.getElementById('step-body');
  if (!body) return;
  const active = document.activeElement;
  const key = active?.dataset?.key;
  const pos = active && 'selectionStart' in active ? [active.selectionStart, active.selectionEnd] : null;
  const scrollY = window.scrollY;
  fillBody(body, step || steps()[state.i - 2]);
  window.scrollTo(0, scrollY);
  if (key) {
    const el = body.querySelector(`[data-key="${CSS.escape(key)}"]`);
    if (el) {
      el.focus({ preventScroll: true });
      try { if (pos && el.setSelectionRange && el.type !== 'email' && el.type !== 'date') el.setSelectionRange(pos[0], pos[1]); } catch {}
    }
  }
}

function refreshIfNeeded() {
  const step = steps()[state.i - 2];
  if (step?.kind === 'form' && visSig(step) !== state.sig) rebuildBody(step);
}

// ---------------------------------------------------------------- Field rendering
function setFieldError(key, errKey) {
  if (errKey) state.errors[key] = errKey;
  else delete state.errors[key];
  const w = document.querySelector(`[data-field-key="${key}"]`);
  if (!w) return;
  w.classList.toggle('has-error', !!errKey);
  const box = w.querySelector('.field__error');
  clear(box);
  if (errKey) {
    box.setAttribute('role', 'alert');
    box.append(icon('alert', 15), h('span', {}, t(errKey)));
  } else box.removeAttribute('role');
  w.querySelectorAll('input:not([type=radio]):not([type=checkbox]),select,textarea').forEach((c) => (errKey ? c.setAttribute('aria-invalid', 'true') : c.removeAttribute('aria-invalid')));
}

const WIDE_TYPES = new Set(['yesno', 'radio', 'multicheck', 'textarea']);

function renderField(f, { src, prefix, scope, item }) {
  const key = prefix + f.id;
  const id = 'f_' + key.replace(/[^A-Za-z0-9]/g, '_');
  const cfg = state.cfg;
  const required = isRequired(f, state.data, cfg, scope);
  const errKey = state.errors[key];
  const label = t(labelKeyOf(f));
  const hint = f.hintKey ? t(f.hintKey) : '';
  const validate = () => setFieldError(key, fieldError(f, src[f.id], { data: state.data, cfg, item, scope }));
  const set = (v) => { src[f.id] = v; state.dirty = true; if (state.errors[key]) validate(); };
  const commit = () => { validate(); refreshIfNeeded(); };
  const group = ['yesno', 'radio', 'multicheck'].includes(f.type);
  let control;

  const baseAttrs = { id, dataset: { key }, 'aria-required': required ? 'true' : null, required: false };
  const textLike = (type, extra = {}) =>
    h('input', {
      ...baseAttrs, class: 'input', type, value: src[f.id] ?? '', dir: f.dir, autocomplete: f.autocomplete || 'off', inputmode: f.inputmode || (type === 'tel' ? 'tel' : type === 'email' ? 'email' : null),
      maxlength: f.maxLen || 200, spellcheck: 'false', autocapitalize: f.dir === 'ltr' ? 'off' : null, enterkeyhint: 'next',
      onInput: (e) => set(e.target.value), onChange: commit, ...extra,
    });

  switch (f.type) {
    case 'text': control = textLike('text'); break;
    case 'email': control = textLike('email'); break;
    case 'tel': control = textLike('tel'); break;
    case 'idnumber': control = textLike('text', { inputmode: 'text', maxlength: 30 }); break;
    case 'swift': control = textLike('text', { maxlength: 11, autocapitalize: 'characters', onInput: (e) => set(e.target.value.toUpperCase()) }); break;
    case 'iban':
      control = textLike('text', { maxlength: 42, autocapitalize: 'characters', onInput: (e) => set(e.target.value), onChange: (e) => { e.target.value = e.target.value.replace(/[\s-]/g, '').toUpperCase(); set(e.target.value); commit(); } });
      break;
    case 'date': {
      const today = new Date().toISOString().slice(0, 10);
      control = textLike('date', { max: f.dateKind === 'past' ? today : null, min: '1900-01-01', dir: 'ltr', maxlength: null, inputmode: null });
      break;
    }
    case 'amount': {
      const inp = textLike('text', {
        inputmode: 'decimal', dir: 'ltr', maxlength: 20,
        value: formatThousands(src[f.id] ?? ''),
        onInput: (e) => { const raw = e.target.value.replace(/[^\d.]/g, ''); set(raw); },
        onChange: (e) => { e.target.value = formatThousands(src[f.id] ?? ''); commit(); },
      });
      control = h('div', { class: 'amount' }, inp, h('span', { class: 'amount__cur', 'aria-hidden': 'true' }, cfg.currency));
      break;
    }
    case 'textarea':
      control = h('textarea', { ...baseAttrs, class: 'textarea', rows: 3, maxlength: 2000, onInput: (e) => set(e.target.value), onChange: commit }, src[f.id] ?? '');
      break;
    case 'select':
    case 'signatorySelect':
    case 'eligibility': {
      let opts;
      if (f.type === 'select') opts = f.options.map((v) => ({ value: v, label: t(optionKeyOf(f, v)) }));
      else if (f.type === 'signatorySelect') opts = (state.data.signatories || []).map((s, i) => ({ value: String(i), label: `${i + 1}. ${s?.nameHe || s?.nameEn || t('ui.signatoryItem', { n: i + 1 })}` }));
      else opts = cfg.eligibilityOptions || [];
      if (f.type === 'eligibility' && !opts.length) { control = textLike('text', { maxlength: 300 }); break; }
      control = h('div', { class: 'selectwrap' },
        h('select', { ...baseAttrs, class: 'select', onChange: (e) => { set(e.target.value); commit(); } },
          h('option', { value: '' }, t('ui.select')),
          opts.map((o) => h('option', { value: o.value, selected: String(src[f.id]) === String(o.value) }, o.label))),
        h('span', { class: 'selectwrap__chev', 'aria-hidden': 'true' }, icon('chevron', 18)));
      break;
    }
    case 'country': {
      const cb = countryCombobox({ id, value: src[f.id], onChange: (code) => { set(code); commit(); } });
      control = cb.wrap;
      break;
    }
    case 'yesno':
    case 'radio': {
      const options = f.type === 'yesno' ? [{ value: 'yes', label: t('ui.yes') }, { value: 'no', label: t('ui.no') }] : f.options.map((v) => ({ value: v, label: t(optionKeyOf(f, v)) }));
      control = choiceGroup({ id, name: key, options, value: src[f.id], compact: f.type === 'yesno' || options.length <= 2, onChange: (v) => { set(v); commit(); } });
      break;
    }
    case 'multicheck': {
      const options = f.options.map((v) => ({ value: v, label: t(optionKeyOf(f, v)) }));
      control = checkGroup({ id, options, values: src[f.id] || [], onChange: (vals) => { set(vals); commit(); } });
      break;
    }
    default:
      control = textLike('text');
  }
  const inputEl = control.matches?.('input,select,textarea') ? control : null;
  if (inputEl) describe(inputEl, id, !!hint, !!errKey);
  return fieldShell({ id, label, hint, required: required ? undefined : false, wide: f.wide || WIDE_TYPES.has(f.type), error: errKey ? t(errKey) : '', control, group });
}

// ---------------------------------------------------------------- Repeating groups
function renderList(f) {
  const arr = state.data[f.id];
  const cfg = state.cfg;
  const min = f.min || 1;
  const nodes = arr.map((item, i) => {
    const prefix = `${f.id}.${i}.`;
    const fields = f.fields.filter((sf) => fieldVisible(sf, state.data, cfg, item || {}));
    return h('div', { class: 'item', role: 'group', 'aria-label': t(f.itemLabelKey, { n: i + 1 }) },
      h('div', { class: 'item__head' },
        h('h3', { class: 'item__title' }, t(f.itemLabelKey, { n: i + 1 })),
        arr.length > min ? h('button', { type: 'button', class: 'btn btn--ghost btn--sm btn--danger', onClick: () => removeItem(f, i) }, icon('trash', 16), t('ui.remove')) : null),
      h('div', { class: 'grid' }, fields.map((sf) => renderField(sf, { src: item, prefix, scope: f.id, item }))));
  });
  return h('div', { class: 'list field--wide', id: 'list-' + f.id },
    f.id === 'crs' ? h('div', { class: 'note' }, icon('file', 18), h('p', {}, t('n.crs'))) : null,
    nodes,
    arr.length < (f.max || 20) ? h('button', { type: 'button', class: 'btn btn--secondary list__add', onClick: () => addItem(f) }, icon('plus', 18), t(f.addLabelKey).replace(/^\+\s*/, '')) : null);
}
function addItem(f) {
  state.data[f.id].push({});
  state.dirty = true;
  rebuildBody();
  const items = document.querySelectorAll(`#list-${f.id} .item`);
  const last = items[items.length - 1];
  last?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  last?.querySelector('input:not(.sr-only),select,textarea')?.focus({ preventScroll: true });
}
function removeItem(f, i) {
  state.data[f.id].splice(i, 1);
  for (const k of Object.keys(state.errors)) if (k.startsWith(f.id + '.')) delete state.errors[k];
  state.dirty = true;
  rebuildBody();
}

// ---------------------------------------------------------------- Documents
const uploader = () =>
  createUploader({
    cfg: state.cfg,
    files: state.files,
    rerender: (docId) => rerenderDoc(docId),
    onChange: () => { state.dirty = true; revalidateDocs(); },
    progress: (docId, entry) => {
      const bar = document.querySelector(`[data-pct="${entry.lid}"]`);
      if (!bar) return;
      bar.style.width = entry.progress + '%';
      bar.parentElement.setAttribute('aria-valuenow', String(entry.progress));
      const sub = bar.closest('li')?.querySelector('.file__sub');
      if (sub) sub.textContent = `${t('up.uploading')} ${entry.progress}%`;
    },
    setError: (docId, msg) => { state.uploadErr[docId] = msg; if (!msg) delete state.errors['doc.' + docId]; },
  });
let up;

function docErr(doc) {
  return state.uploadErr[doc.id] || (state.errors['doc.' + doc.id] ? t(state.errors['doc.' + doc.id]) : '');
}
function rerenderDoc(docId) {
  const doc = docsFor(state.type, state.data, state.cfg).find((d) => d.id === docId);
  const cont = document.getElementById('doccont-' + docId);
  if (!doc || !cont) return;
  const hadFocus = document.activeElement?.closest?.('#doccont-' + docId);
  clear(cont);
  const err = docErr(doc);
  cont.append(up.card(doc, err));
  cont.classList.toggle('doc--has-error', !!err);
  if (hadFocus) cont.querySelector('label[role=button],button')?.focus({ preventScroll: true });
}
function rebuildDocs() {
  const list = docsFor(state.type, state.data, state.cfg);
  for (const doc of list) rerenderDoc(doc.id);
}
function revalidateDocs() {
  const step = steps().find((s) => s.kind === 'docs');
  const errs = validateStep(state.type, step, state.data, state.files, state.cfg, true);
  for (const k of Object.keys(state.errors)) if (k.startsWith('doc.')) delete state.errors[k];
  // only surface "missing" errors after the user has tried to continue; clear resolved ones live
  for (const doc of docsFor(state.type, state.data, state.cfg)) {
    if ((state.files[doc.id] || []).some((f) => f.status === 'done')) delete state.uploadErr[doc.id];
  }
  void errs;
}

function docsScreen(step) {
  up = uploader();
  const list = docsFor(state.type, state.data, state.cfg);
  const cards = list.map((doc) => {
    const err = docErr(doc);
    return h('div', { id: 'doccont-' + doc.id, class: err ? 'doc--has-error' : '' }, up.card(doc, err));
  });
  return h('main', { class: 'stage' },
    progressHead(step.titleKey, state.i, steps().length + 1),
    h('div', { class: 'note note--lead' }, icon('camera', 20), h('p', {}, t('n.docsLead'))),
    h('div', { class: 'docs', id: 'sec-docs' }, cards),
    navBar(navHandlers()));
}

// ---------------------------------------------------------------- Review & submit
function reviewScreen(step) {
  const list = steps();
  const summary = buildSummary(state.type, state.data, doneFiles(), state.cfg, { includeEmpty: true });
  const cards = summary.map((sec) =>
    h('section', { class: 'review__card', 'aria-labelledby': 'rv-' + sec.key },
      h('div', { class: 'review__head' },
        h('h2', { class: 'review__title', id: 'rv-' + sec.key }, sec.title),
        h('button', { type: 'button', class: 'btn btn--ghost btn--sm', onClick: () => { state.fromReview = true; go(sec.stepIndex + 2, { scrollTo: 'sec-' + sec.key }); } }, icon('pencil', 15), t('ui.edit'))),
      sec.blocks.map((b) =>
        h('div', { class: 'review__block' },
          b.title ? h('h3', { class: 'review__sub' }, b.title) : null,
          h('dl', { class: 'review__list' }, b.rows.map((r) => h('div', { class: `review__row ${r.missing ? 'is-missing' : ''}` }, h('dt', {}, r.label), h('dd', { dir: r.ltr ? 'ltr' : null, class: r.ltr ? 'ltr-right' : '' }, r.multiline ? r.value.split('\n').map((v) => h('div', {}, v)) : r.value))))))));

  const declErr = state.errors.declaration;
  const declId = 'declaration';
  const decl = h('div', { class: `field field--wide decl ${declErr ? 'has-error' : ''}`, dataset: { fieldKey: 'declaration' } },
    h('label', { class: 'choice__item choice__item--decl', for: declId },
      h('input', { type: 'checkbox', id: declId, checked: state.declared, dataset: { key: declId }, 'aria-describedby': 'declaration-err', onChange: (e) => { state.declared = e.target.checked; if (state.declared) setFieldError('declaration', null); } }),
      h('span', { class: 'choice__box', 'aria-hidden': 'true' }, icon('check', 14)),
      h('span', { class: 'choice__text' }, cfgText('declaration', 'decl.text'))),
    h('div', { class: 'field__error', id: 'declaration-err', role: declErr ? 'alert' : null }, declErr ? [icon('alert', 15), h('span', {}, t(declErr))] : null));

  const tsBox = state.cfg.turnstileSiteKey ? h('div', { id: 'turnstile', class: 'turnstile', 'aria-label': t('ui.captcha') }) : null;
  const honey = h('div', { class: 'hp', 'aria-hidden': 'true' }, h('input', { type: 'text', name: 'website', id: 'hp', tabindex: '-1', autocomplete: 'off' }));
  const banner = h('div', { class: 'banner', id: 'banner', role: 'alert', hidden: !state.banner }, icon('alert', 18), h('span', {}, state.banner));

  const screen = h('main', { class: 'stage' },
    progressHead(step.titleKey, state.i, list.length + 1),
    h('p', { class: 'stephead__lead' }, t('ui.review.lead')),
    h('div', { class: 'review' }, cards),
    decl, honey, tsBox, banner,
    navBar({ onBack: () => go(state.i - 1), onNext: submit, nextLabel: t('ui.submit'), nextIcon: false, showSave: false }));
  if (tsBox) queueMicrotask(mountTurnstile);
  return screen;
}

function mountTurnstile() {
  const el = document.getElementById('turnstile');
  if (!el) return;
  const draw = () => window.turnstile?.render(el, { sitekey: state.cfg.turnstileSiteKey, language: 'he', callback: (tk) => (state.turnstile = tk), 'expired-callback': () => (state.turnstile = '') });
  if (window.turnstile) return draw();
  const s = document.createElement('script');
  s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
  s.async = true;
  s.onload = draw;
  document.head.append(s);
}

function showBanner(msg, diag = '') {
  state.banner = msg;
  const b = document.getElementById('banner');
  if (!b) return;
  b.hidden = !msg;
  clear(b);
  if (msg) b.append(icon('alert', 18), h('span', {}, msg, diag ? h('small', { class: 'diag', dir: 'ltr' }, diag) : null));
  b.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

function overlay(on) {
  document.getElementById('overlay')?.remove();
  document.body.classList.toggle('is-busy', on);
  if (!on) return;
  document.body.append(h('div', { class: 'overlay', id: 'overlay', role: 'alertdialog', 'aria-modal': 'true', 'aria-live': 'assertive', 'aria-label': t('ui.sending') },
    h('div', { class: 'overlay__box' }, h('div', { class: 'spinner', 'aria-hidden': 'true' }), h('p', { class: 'overlay__title' }, t('ui.sending')), h('p', { class: 'overlay__sub' }, t('ui.sendingSub')))));
}

async function submit() {
  if (state.submitting) return;
  const res = validateAll(state.type, state.data, state.files, state.cfg, state.declared);
  if (!res.ok) {
    state.errors = res.errors;
    if (res.firstStepIndex !== steps().length - 1) {
      go(res.firstStepIndex + 2);
      showBanner(t('fail.validation'));
      setTimeout(() => document.querySelector('.has-error')?.scrollIntoView({ block: 'center' }), 50);
      return;
    }
    render();
    document.getElementById('declaration')?.focus();
    announce(t('e.declaration'));
    return;
  }
  if (document.getElementById('hp')?.value) return;
  state.submitting = true;
  overlay(true);
  try {
    const files = Object.fromEntries(Object.entries(doneFiles()).map(([k, l]) => [k, l.map((f) => ({ token: f.token }))]));
    const r = await postJSON('/api/submit', { type: state.type, data: state.data, files, declaration: true, submissionKey: state.key, hp: document.getElementById('hp')?.value || '', turnstile: state.turnstile });
    if (r.ok && r.body.ref) {
      state.ref = r.body.ref;
      try { sessionStorage.setItem('asai.done', JSON.stringify({ ref: state.ref })); } catch {}
      // wipe sensitive data from memory
      state.data = {}; state.files = {}; state.dirty = false;
      state.submitting = false;
      overlay(false);
      history.replaceState({ i: 'success' }, '');
      go('success', { push: false });
      return;
    }
    throw Object.assign(new Error('submit'), { status: r.status, code: r.body?.error, stage: r.body?.stage });
  } catch (e) {
    state.submitting = false;
    overlay(false);
    const msg = e.status === 429 ? t('fail.rate') : e.status === 401 ? t('fail.session') : t('fail.submit');
    if (e.status === 422) {
      // server disagreed with the client – jump to the first problem
      render();
    }
    showBanner(msg, e.stage ? `${e.status || ''}/${e.stage}` : '');
  }
}

// ---------------------------------------------------------------- Success
function successMark() {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 52 52');
  svg.setAttribute('class', 'checkmark');
  svg.setAttribute('aria-hidden', 'true');
  const c = document.createElementNS(NS, 'circle');
  c.setAttribute('class', 'checkmark__circle'); c.setAttribute('cx', '26'); c.setAttribute('cy', '26'); c.setAttribute('r', '24'); c.setAttribute('fill', 'none');
  const p = document.createElementNS(NS, 'path');
  p.setAttribute('class', 'checkmark__tick'); p.setAttribute('fill', 'none'); p.setAttribute('d', 'M14 27l8 8 16-17');
  svg.append(c, p);
  return svg;
}
function successScreen() {
  return h('main', { class: 'hero hero--success' },
    h('img', { class: 'hero__mark', src: state.cfg.brand.logoMark, alt: '', 'aria-hidden': 'true' }),
    h('div', { class: 'hero__card' },
      successMark(),
      h('h1', { class: 'hero__title', id: 'heading', tabindex: '-1' }, cfgText('successTitle', 'success.title')),
      h('p', { class: 'hero__lead' }, cfgText('successText', 'success.text')),
      h('div', { class: 'refchip', dir: 'auto' }, t('success.ref', { ref: state.ref }))));
}

// ---------------------------------------------------------------- Save & continue
async function saveDraft() {
  const btn = document.querySelector('.navbar__save');
  if (btn) btn.disabled = true;
  const files = Object.fromEntries(Object.entries(doneFiles()).map(([k, l]) => [k, l.map(({ token, name, size, type }) => ({ token, name, size, type }))]));
  const r = await postJSON('/api/resume', { action: 'save', type: state.type, data: state.data, files, stepIndex: state.i });
  if (btn) btn.disabled = false;
  if (!r.ok) return showToast(t('ui.saveDraft.failed'));
  const url = `${location.origin}${location.pathname}#r=${r.body.token}`;
  state.dirty = false;
  const dlg = h('dialog', { class: 'modal', 'aria-labelledby': 'dlg-t' },
    h('h2', { id: 'dlg-t', class: 'modal__title' }, t('ui.saveDraft.title')),
    h('p', {}, t('ui.saveDraft.lead', { days: r.body.days })),
    h('input', { class: 'input modal__url', readonly: true, dir: 'ltr', value: url, 'aria-label': t('ui.saveDraft.title'), onFocus: (e) => e.target.select() }),
    h('p', { class: 'modal__note' }, t('ui.saveDraft.note')),
    h('div', { class: 'modal__actions' },
      h('button', { type: 'button', class: 'btn btn--secondary', onClick: async (e) => { try { await navigator.clipboard.writeText(url); e.currentTarget.textContent = t('ui.saveDraft.copied'); } catch { dlg.querySelector('.modal__url').select(); } } }, icon('copy', 16), t('ui.saveDraft.copy')),
      h('button', { type: 'button', class: 'btn btn--primary', onClick: () => { dlg.close(); dlg.remove(); } }, t('ui.saveDraft.close'))));
  document.body.append(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.showModal();
}
function showToast(msg) {
  const el = h('div', { class: 'toast', role: 'status' }, icon('alert', 16), msg);
  document.body.append(el);
  setTimeout(() => el.remove(), 5000);
}

async function resumeFromHash() {
  const token = location.hash.slice(3);
  history.replaceState(null, '', location.pathname); // remove the secret from the URL immediately
  $app.append(h('main', { class: 'hero' }, h('div', { class: 'hero__card' }, h('div', { class: 'spinner' }), h('p', { class: 'hero__lead' }, t('ui.resume.loading')))));
  const r = await postJSON('/api/resume', { action: 'load', token });
  if (!r.ok) {
    go(0, { push: false });
    return showToast(t('ui.resume.failed'));
  }
  setSession(r.body.session);
  state.type = r.body.type;
  state.data = { ...initialData(state.type), ...r.body.data };
  state.files = Object.fromEntries(Object.entries(r.body.files || {}).map(([k, l]) => [k, l.map((f, n) => ({ ...f, lid: 9000 + n + Math.random(), status: 'done', progress: 100 }))]));
  const idx = Math.min(Number(r.body.stepIndex) || 2, steps().length + 1);
  history.replaceState({ i: idx }, '');
  go(Math.max(2, idx), { push: false });
  showToast(t('ui.resume.welcome'));
}

// =====================================================================================
// Boot
// =====================================================================================
function applyBrand(cfg) {
  for (const [k, v] of Object.entries(cfg.brand.colors || {})) if (/^--[a-z0-9-]+$/.test(k) && /^#[0-9a-fA-F]{3,8}$/.test(v)) document.documentElement.style.setProperty(k, v);
  document.title = `${t('intro.title')} | ${cfg.brand.name}`;
}

async function boot() {
  try {
    const j = await init_();
    state.cfg = j.config;
    applyBrand(state.cfg);
  } catch (e) {
    // Non-sensitive diagnostic code (HTTP status + error code) to help support identify deployment problems.
    const diag = `${e?.status ?? 'net'}/${e?.code ?? e?.name ?? 'err'}`;
    $app.append(h('main', { class: 'hero' }, h('div', { class: 'hero__card' }, h('div', { class: 'banner' }, icon('alert', 18), t('fail.load')), h('p', { class: 'hero__foot', dir: 'ltr' }, diag), h('button', { class: 'btn btn--primary', onClick: () => location.reload() }, icon('refresh', 18), t('up.retry')))));
    return;
  }
  let done = null;
  try { done = JSON.parse(sessionStorage.getItem('asai.done') || 'null'); } catch {}
  if (done?.ref) {
    state.ref = done.ref;
    history.replaceState({ i: 'success' }, '');
    return go('success', { push: false });
  }
  if (location.hash.startsWith('#r=')) return resumeFromHash();
  history.replaceState({ i: 0 }, '');
  go(0, { push: false });
}
boot();
