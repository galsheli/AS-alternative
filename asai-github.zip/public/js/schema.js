// Data-driven questionnaire definition. Shared by the browser (rendering, review)
// and the server (validation, pruning, PDF, email) so both always agree.
// Text lives in i18n/he.js:  label  -> f.<id>  (or labelKey)
//                            option -> o.<optionsNs || id>.<value>
//                            step   -> st.<id>   section -> s.<id>

export const YN = ['yes', 'no'];
const isYes = (v) => v === 'yes';

// ---------- Field factories ----------
const text = (id, extra = {}) => ({ id, type: 'text', ...extra });

const bankFields = (p, addrKey) => [
  text(p + 'bankName', { labelKey: 'f.bankName', autocomplete: 'off' }),
  text(p + 'bankNumber', { labelKey: 'f.bankNumber', dir: 'ltr', inputmode: 'numeric', required: false, maxLen: 10 }),
  text(p + 'branch', { labelKey: 'f.branch', dir: 'ltr', inputmode: 'numeric', required: false, maxLen: 10 }),
  text(p + 'account', { labelKey: 'f.account', dir: 'ltr', maxLen: 34 }),
  { id: p + 'iban', type: 'iban', labelKey: 'f.iban', hintKey: 'h.iban', dir: 'ltr' },
  { id: p + 'swift', type: 'swift', labelKey: 'f.swift', hintKey: 'h.swift', dir: 'ltr', required: false },
  text(p + 'bankAddress', { labelKey: addrKey, maxLen: 300, wide: true }),
];

const foreignActivityFields = (nsKey) => [
  { id: 'foreignActivity', type: 'yesno', labelKey: nsKey },
  text('foreignActivityType', { showIf: (d) => isYes(d.foreignActivity), maxLen: 300 }),
  { id: 'foreignActivityCountry', type: 'country', showIf: (d) => isYes(d.foreignActivity) },
];

const addressFields = (addrKey, extra = {}) => [
  text('address', { labelKey: addrKey, autocomplete: 'street-address', wide: true, maxLen: 300, ...extra }),
  text('city', { autocomplete: 'address-level2', maxLen: 100 }),
  { id: 'country', type: 'country', autocomplete: 'country-name' },
  text('postalCode', { autocomplete: 'postal-code', dir: 'ltr', maxLen: 20 }),
];

// ---------- Individual ----------
const individual = {
  steps: [
    {
      id: 'ind.personal',
      sections: [
        {
          id: 'ind.personal',
          fields: [
            text('firstNameEn', { latin: true, autocomplete: 'given-name', dir: 'ltr', maxLen: 60 }),
            text('lastNameEn', { latin: true, autocomplete: 'family-name', dir: 'ltr', maxLen: 60 }),
            text('firstNameHe', { maxLen: 60 }),
            text('lastNameHe', { maxLen: 60 }),
            { id: 'email', type: 'email', autocomplete: 'email', dir: 'ltr', wide: true },
            { id: 'idType', type: 'radio', options: ['id', 'passport'] },
            { id: 'idNumber', type: 'idnumber', dir: 'ltr' },
            { id: 'birthDate', type: 'date', dateKind: 'past', hintKey: 'h.birthDate', autocomplete: 'bday' },
            { id: 'phone', type: 'tel', autocomplete: 'tel', dir: 'ltr', hintKey: 'h.phone' },
            ...addressFields('f.address'),
            { id: 'birthCountry', type: 'country' },
          ],
        },
        {
          id: 'ind.investment',
          fields: [
            { id: 'amount', type: 'amount' },
            { id: 'eligibility', type: 'eligibility', wide: true },
          ],
        },
      ],
    },
    {
      id: 'ind.bank',
      sections: [
        { id: 'bankInv', group: 'bank', noteKey: 'n.bankInv', fields: bankFields('inv_', 'f.bankAddress') },
        {
          id: 'bankPayQ',
          group: 'bank',
          fields: [{ id: 'paymentSame', type: 'yesno', labelKey: 'f.paymentSame.ind' }],
        },
        {
          id: 'bankPay',
          group: 'bank',
          noteKey: 'n.bankPay',
          showIf: (d) => d.paymentSame === 'no',
          fields: bankFields('pay_', 'f.bankAddressPay'),
        },
      ],
    },
    {
      id: 'ind.kyc',
      sections: [
        {
          id: 'ind.kyc',
          fields: [
            { id: 'occupationType', type: 'select', options: ['selfEmployed', 'employee', 'controlEmployee', 'other'] },
            text('occupationOther', { showIf: (d) => d.occupationType === 'other', maxLen: 300 }),
            { id: 'jobTitle', type: 'textarea', wide: true },
            { id: 'ownsBusiness', type: 'yesno' },
            text('businessField', { showIf: (d) => isYes(d.ownsBusiness), maxLen: 300 }),
            {
              id: 'fundsSource',
              type: 'multicheck',
              labelKey: 'f.fundsSource.ind',
              optionsNs: 'fundsSource.ind',
              options: ['salary', 'savings', 'business', 'investments', 'propertySale', 'inheritance', 'other'],
              wide: true,
            },
            { id: 'fundsOther', type: 'textarea', showIf: (d) => (d.fundsSource || []).includes('other'), wide: true },
            ...foreignActivityFields('f.foreignActivity.ind'),
            { id: 'residency', type: 'radio', options: ['israel', 'foreign'] },
            {
              id: 'israelTie',
              type: 'select',
              options: ['none', 'frequentVisitor', 'relatives', 'works', 'business', 'lives', 'newImmigrant'],
              showIf: (d) => d.residency === 'foreign',
            },
            { id: 'pep', type: 'yesno', labelKey: 'f.pep.ind', hintKey: 'n.pep' },
            { id: 'pepDetails', type: 'textarea', showIf: (d) => isYes(d.pep), wide: true },
          ],
        },
      ],
    },
    {
      id: 'ind.tax',
      sections: [
        { id: 'ind.fatca', fields: [{ id: 'fatcaUS', type: 'yesno' }] },
        {
          id: 'ind.crs',
          fields: [
            {
              id: 'crs',
              type: 'list',
              min: 1,
              max: 10,
              itemLabelKey: 'ui.crsItem',
              addLabelKey: 'ui.addCrs',
              fields: [
                { id: 'country', labelKey: 'f.crs.country', type: 'country' },
                text('tin', { labelKey: 'f.crs.tin', dir: 'ltr', required: false, maxLen: 50 }),
                {
                  id: 'tinReason',
                  labelKey: 'f.crs.tinReason',
                  optionsNs: 'crs.tinReason',
                  type: 'radio',
                  options: ['noIssue', 'cannotProvide', 'notRequired'],
                  showIf: (_d, item) => !String(item?.tin || '').trim(),
                  wide: true,
                },
                {
                  id: 'tinExplain',
                  labelKey: 'f.crs.tinExplain',
                  type: 'textarea',
                  showIf: (_d, item) => !String(item?.tin || '').trim() && item?.tinReason === 'cannotProvide',
                  wide: true,
                },
              ],
            },
          ],
        },
      ],
    },
  ],
  docs: [
    { id: 'doc_id', max: 4, instrKey: (d) => (d.idType === 'id' ? 'di.doc_id.id' : d.idType === 'passport' ? 'di.doc_id.passport' : 'di.doc_id.none') },
    { id: 'doc_address', max: 2 },
    { id: 'doc_bank', max: 2, instrKey: () => 'di.doc_bank.ind' },
    { id: 'doc_bankPay', max: 2, showIf: (d) => d.paymentSame === 'no' },
    { id: 'doc_eligibility', max: 3 },
  ],
  flags: (d) => [isYes(d.pep) && 'pep', isYes(d.fatcaUS) && 'fatcaUS'].filter(Boolean),
  displayName: (d) =>
    [d.firstNameHe, d.lastNameHe].filter(Boolean).join(' ') || [d.firstNameEn, d.lastNameEn].filter(Boolean).join(' '),
  contact: (d) => ({ email: d.email, phone: d.phone }),
};

// ---------- Corporate ----------
const signatoryFields = [
  text('nameEn', { labelKey: 'f.sig.nameEn', latin: true, dir: 'ltr', maxLen: 120 }),
  text('nameHe', { labelKey: 'f.sig.nameHe', maxLen: 120 }),
  { id: 'phone', labelKey: 'f.sig.phone', type: 'tel', dir: 'ltr' },
  { id: 'email', labelKey: 'f.sig.email', type: 'email', dir: 'ltr' },
  text('idNumber', { labelKey: 'f.sig.idNumber', dir: 'ltr', maxLen: 30, idGeneric: true }),
  text('role', { labelKey: 'f.sig.role', maxLen: 100 }),
];

const contactSigOptions = (d) =>
  (d.signatories || []).map((s, i) => String(i)).filter((i) => true);

const corporate = {
  steps: [
    {
      id: 'corp.details',
      sections: [
        {
          id: 'corp.details',
          fields: [
            text('corpNameHe', { maxLen: 150 }),
            text('corpNameEn', { latin: true, dir: 'ltr', maxLen: 150 }),
            text('regNumber', { dir: 'ltr', maxLen: 30 }),
            { id: 'incDate', type: 'date', dateKind: 'past', hintKey: 'h.birthDate' },
            { id: 'corpPhone', type: 'tel', dir: 'ltr', autocomplete: 'tel' },
            ...addressFields('f.corpAddress'),
            { id: 'incCountry', type: 'country' },
          ],
        },
      ],
    },
    {
      id: 'corp.people',
      sections: [
        {
          id: 'corp.signatories',
          fields: [
            {
              id: 'signatories',
              type: 'list',
              min: 1,
              initial: 2,
              max: 20,
              itemLabelKey: 'ui.signatoryItem',
              addLabelKey: 'ui.addSignatory',
              fields: signatoryFields,
            },
          ],
        },
        {
          id: 'corp.contact',
          fields: [
            { id: 'contactIsSignatory', type: 'yesno' },
            {
              id: 'contactSignatory',
              type: 'signatorySelect',
              hintKey: 'h.contactSignatory',
              showIf: (d) => isYes(d.contactIsSignatory),
              depsKey: (d) => (d.signatories || []).map((s) => s?.nameHe || s?.nameEn || '').join('|'),
              wide: true,
            },
            text('contactNameHe', { showIf: (d) => d.contactIsSignatory === 'no', maxLen: 120 }),
            text('contactRole', { showIf: (d) => d.contactIsSignatory === 'no', maxLen: 100 }),
            { id: 'contactPhone', type: 'tel', dir: 'ltr', showIf: (d) => d.contactIsSignatory === 'no' },
            { id: 'contactEmail', type: 'email', dir: 'ltr', showIf: (d) => d.contactIsSignatory === 'no' },
          ],
        },
      ],
    },
    {
      id: 'corp.kyc',
      sections: [
        {
          id: 'corp.kyc',
          fields: [
            { id: 'corpType', type: 'select', options: ['private', 'public', 'nonprofit', 'partnership', 'other'] },
            text('corpTypeOther', { showIf: (d) => d.corpType === 'other', maxLen: 300 }),
            text('corpField', { maxLen: 300, wide: true }),
            {
              id: 'fundsSource',
              type: 'multicheck',
              labelKey: 'f.fundsSource.corp',
              optionsNs: 'fundsSource.corp',
              options: ['loan', 'businessReceipts', 'yieldingInvestments', 'freeFunds', 'other'],
              wide: true,
            },
            { id: 'fundsOther', type: 'textarea', showIf: (d) => (d.fundsSource || []).includes('other'), wide: true },
            ...foreignActivityFields('f.foreignActivity.corp'),
            { id: 'pep', type: 'yesno', labelKey: 'f.pep.corp', hintKey: 'n.pep' },
            { id: 'pepDetails', type: 'textarea', showIf: (d) => isYes(d.pep), wide: true },
          ],
        },
      ],
    },
    {
      id: 'corp.bank',
      sections: [
        { id: 'bankInv', group: 'bank', noteKey: 'n.bankInv', fields: bankFields('inv_', 'f.bankAddress') },
        { id: 'bankPayQ', group: 'bank', fields: [{ id: 'paymentSame', type: 'yesno', labelKey: 'f.paymentSame.corp' }] },
        {
          id: 'bankPay',
          group: 'bank',
          noteKey: 'n.bankPay',
          showIf: (d) => d.paymentSame === 'no',
          fields: bankFields('pay_', 'f.bankAddressPay'),
        },
      ],
    },
    {
      id: 'corp.tax',
      sections: [
        {
          id: 'corp.tax',
          fields: [
            { id: 'usEntity', type: 'yesno', hintKey: 'n.w9' },
            {
              id: 'w9Mode',
              type: 'radio',
              options: ['now', 'later'],
              showIf: (d, cfg) => isYes(d.usEntity) && cfg?.w9AllowLater !== false,
            },
          ],
        },
      ],
    },
  ],
  docs: [
    { id: 'doc_incorporation', max: 6 },
    { id: 'doc_signatoryProtocol', max: 3 },
    { id: 'doc_registryExtract', max: 3 },
    { id: 'doc_controllersId', max: 10 },
    { id: 'doc_bank', max: 2, instrKey: () => 'di.doc_bank.corp' },
    { id: 'doc_bankPay', max: 2, showIf: (d) => d.paymentSame === 'no' },
    { id: 'doc_corpAddress', max: 2 },
    { id: 'doc_eligibility', max: 3 },
    { id: 'doc_w9', max: 3, showIf: (d, cfg) => isYes(d.usEntity) && (cfg?.w9AllowLater === false || d.w9Mode === 'now') },
  ],
  flags: (d) => [isYes(d.pep) && 'pep', isYes(d.usEntity) && 'usEntity', isYes(d.usEntity) && d.w9Mode === 'later' && 'w9Later'].filter(Boolean),
  displayName: (d) => d.corpNameHe || d.corpNameEn || '',
  contact: (d) => {
    if (isYes(d.contactIsSignatory)) {
      const s = (d.signatories || [])[Number(d.contactSignatory)] || (d.signatories || [])[0] || {};
      return { email: s.email, phone: s.phone };
    }
    return { email: d.contactEmail, phone: d.contactPhone || d.corpPhone };
  },
};

export const SCHEMAS = { individual, corporate };
export const TYPES = Object.keys(SCHEMAS);

// ---------- Helpers ----------
/** Steps for the wizard (form steps + docs + review), as descriptors. */
export function wizardSteps(type) {
  const s = SCHEMAS[type];
  if (!s) return [];
  return [
    ...s.steps.map((st) => ({ kind: 'form', id: st.id, titleKey: 'st.' + st.id, def: st })),
    { kind: 'docs', id: 'docs', titleKey: 'st.docs' },
    { kind: 'review', id: 'review', titleKey: 'st.review' },
  ];
}

export const labelKeyOf = (f) => f.labelKey || 'f.' + f.id;
export const optionKeyOf = (f, v) => 'o.' + (f.optionsNs || f.id) + '.' + v;

export function isVisible(item, d, cfg, listItem) {
  return typeof item.showIf === 'function' ? !!item.showIf(d, listItem !== undefined ? listItem : cfg, cfg) : true;
}

/** Field visibility with config + list-item awareness. */
export function fieldVisible(f, d, cfg, item) {
  if (typeof f.showIf !== 'function') return true;
  // showIf signature: (data, itemOrCfg, cfg). List-item fields use (d, item); top-level use (d, cfg).
  return !!(item !== undefined ? f.showIf(d, item, cfg) : f.showIf(d, cfg));
}
export const sectionVisible = (s, d, cfg) => (typeof s.showIf === 'function' ? !!s.showIf(d, cfg) : true);

export function isRequired(f, d, cfg, scope = '') {
  const ov = cfg?.fieldOverrides?.[scope ? scope + '.' + f.id : f.id];
  if (ov && typeof ov.required === 'boolean') return ov.required;
  if (typeof f.required === 'function') return !!f.required(d);
  return f.required !== false;
}

export function docsFor(type, d, cfg) {
  const list = SCHEMAS[type]?.docs || [];
  return list
    .filter((doc) => (typeof doc.showIf === 'function' ? doc.showIf(d, cfg) : true))
    .map((doc) => ({
      ...doc,
      required: cfg?.docOverrides?.[doc.id]?.required ?? doc.required ?? true,
      instr: typeof doc.instrKey === 'function' ? doc.instrKey(d) : doc.instrKey || 'di.' + doc.id,
    }));
}

/** Initial (empty) data for an investor type. */
export function initialData(type) {
  const d = {};
  for (const st of SCHEMAS[type].steps)
    for (const sec of st.sections)
      for (const f of sec.fields) {
        if (f.type === 'list') d[f.id] = Array.from({ length: f.initial || f.min || 1 }, () => ({}));
        else if (f.type === 'multicheck') d[f.id] = [];
        else d[f.id] = '';
      }
  return d;
}

/** Keep only fields that exist AND are currently visible; drop everything else. */
export function pruneData(type, data, cfg) {
  const out = {};
  const s = SCHEMAS[type];
  const d = data || {};
  for (const st of s.steps)
    for (const sec of st.sections) {
      if (!sectionVisible(sec, d, cfg)) continue;
      for (const f of sec.fields) {
        if (!fieldVisible(f, d, cfg)) continue;
        if (f.type === 'list') {
          const arr = Array.isArray(d[f.id]) ? d[f.id].slice(0, f.max || 20) : [];
          out[f.id] = arr.map((item) => {
            const o = {};
            for (const sf of f.fields) if (fieldVisible(sf, d, cfg, item || {})) o[sf.id] = item?.[sf.id] ?? '';
            return o;
          });
        } else out[f.id] = d[f.id] ?? (f.type === 'multicheck' ? [] : '');
      }
    }
  return out;
}
