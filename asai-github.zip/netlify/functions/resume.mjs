import crypto from 'node:crypto';
import { store, STORES } from '../lib/storage.mjs';
import { json, fail, requireSession, sameOrigin, rateLimit, randomId, issueSession, encryptJSON, decryptJSON, sanitizeDeep } from '../lib/security.mjs';
import { cfgNow } from '../lib/common.mjs';
import { SCHEMAS } from '../../public/js/schema.js';

const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

// Save & continue: encrypted draft, random 256-bit token (kept in the URL fragment, never sent
// to servers/logs by the browser), automatic expiry. Nothing is stored in browser localStorage.
export default async (req) => {
  try {
    if (req.method !== 'POST') return fail('method', 405);
    if (!sameOrigin(req)) return fail('forbidden', 403);
    const cfg = cfgNow();
    if (!cfg.enableResume) return fail('disabled', 404);
    if (!(await rateLimit(req, 'resume', 30, 3600))) return fail('rate', 429);

    const raw = await req.text();
    if (raw.length > 600_000) return fail('size', 413);
    const body = JSON.parse(raw);
    const drafts = await store(STORES.drafts);

    if (body.action === 'save') {
      const session = requireSession(req);
      if (!session) return fail('session', 401);
      if (!SCHEMAS[body.type]) return fail('bad_request', 400);
      const files = {};
      for (const [k, list] of Object.entries(body.files || {}))
        if (/^doc_[A-Za-z0-9]+$/.test(k) && Array.isArray(list))
          files[k] = list.filter((f) => f?.token && /^[A-Za-z0-9_-]{20,64}$/.test(f.token)).slice(0, 12)
            .map((f) => ({ token: f.token, name: String(f.name || '').slice(0, 120), size: Number(f.size) || 0, type: String(f.type || '') }));
      const token = randomId(32);
      const expiresAt = Date.now() + cfg.resumeDays * 86400_000;
      const payload = { sid: session.sid, type: body.type, data: sanitizeDeep(body.data || {}), files, stepIndex: Number(body.stepIndex) || 0, expiresAt };
      await drafts.setBuffer(hashToken(token), encryptJSON(payload), { metadata: { expiresAt } });
      return json({ ok: true, token, expiresAt, days: cfg.resumeDays });
    }

    if (body.action === 'load') {
      const token = String(body.token || '');
      if (!/^[A-Za-z0-9_-]{40,60}$/.test(token)) return fail('invalid', 400);
      const rec = await drafts.getBuffer(hashToken(token));
      if (!rec) return fail('invalid', 404);
      const p = decryptJSON(rec.data);
      if (p.expiresAt < Date.now()) {
        await drafts.del(hashToken(token));
        return fail('expired', 410);
      }
      return json({ ok: true, type: p.type, data: p.data, files: p.files, stepIndex: p.stepIndex, session: issueSession(p.sid).token });
    }
    return fail('bad_request', 400);
  } catch (e) {
    console.error('resume_failed', e?.message);
    return fail('server', 500);
  }
};
export const config = { path: '/api/resume' };
