import { serverEnv } from '../../config/site.config.mjs';
import { store, STORES } from '../lib/storage.mjs';

// Scheduled daily. Retention is configurable via env (0 = keep):
//   RETENTION_UPLOADS_DAYS, RETENTION_SUBMISSIONS_DAYS.  Orphaned uploads (never submitted) and
//   expired drafts are always removed after 30 days / their expiry.
export default async () => {
  const env = serverEnv();
  const now = Date.now();
  const day = 86400_000;
  const uploads = await store(STORES.uploads);
  const misc = await store(STORES.misc);
  let removed = 0;
  for (const key of await uploads.list()) {
    const rec = await uploads.getBuffer(key);
    const age = now - (rec?.metadata?.createdAt || 0);
    const used = await misc.getJSON(`used:${key}`);
    const limit = used ? (env.retention.uploadsDays || 0) * day : 30 * day;
    if (limit > 0 && age > limit) {
      await uploads.del(key);
      await misc.del(`used:${key}`);
      removed++;
    }
  }
  const drafts = await store(STORES.drafts);
  for (const key of await drafts.list()) {
    const rec = await drafts.getBuffer(key);
    if ((rec?.metadata?.expiresAt || 0) < now) await drafts.del(key);
  }
  if (env.retention.submissionsDays > 0) {
    const meta = await store(STORES.meta);
    const data = await store(STORES.data);
    const pdf = await store(STORES.pdf);
    for (const ref of await meta.list()) {
      const m = await meta.getJSON(ref);
      if (m && now - Date.parse(m.submittedAt) > env.retention.submissionsDays * day) {
        await data.del(ref);
        await pdf.del(ref);
        await meta.del(ref);
      }
    }
  }
  console.log('purge_done', removed);
  return new Response('ok');
};
export const config = { schedule: '@daily' };
