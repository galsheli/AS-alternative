import { store, STORES } from '../lib/storage.mjs';
import { json, fail, requireSession, sameOrigin, rateLimit, randomId } from '../lib/security.mjs';
import { sniff, pdfLooksUnsafe, safeFileName } from '../lib/files.mjs';
import { cfgNow, MB } from '../lib/common.mjs';
import { SCHEMAS } from '../../public/js/schema.js';

const KNOWN_DOCS = new Set(Object.values(SCHEMAS).flatMap((s) => s.docs.map((d) => d.id)));

// One file per request (raw binary body). Stored privately in Netlify Blobs under an unguessable id.
export default async (req) => {
  try {
    if (req.method !== 'POST') return fail('method', 405);
    if (!sameOrigin(req)) return fail('forbidden', 403);
    const session = requireSession(req);
    if (!session) return fail('session', 401);
    // Rate limiting must never block legitimate uploads if storage hiccups; limit is generous (per IP / hour).
    try {
      if (!(await rateLimit(req, 'upload', 400, 3600))) return fail('rate', 429);
    } catch (e) {
      console.error('upload_ratelimit_unavailable:', e?.message);
    }

    const cfg = cfgNow();
    const maxBytes = Math.min(cfg.maxFileMB, 4.5) * MB;
    const declared = Number(req.headers.get('content-length') || 0);
    if (declared > maxBytes + 1024) return fail('size', 413);

    const url = new URL(req.url);
    const docId = url.searchParams.get('doc') || '';
    if (!KNOWN_DOCS.has(docId)) return fail('doc', 400);

    const buf = Buffer.from(await req.arrayBuffer());
    if (buf.length === 0) return fail('empty', 400);
    if (buf.length > maxBytes) return fail('size', 413);

    const kind = sniff(buf);
    if (!kind) return fail('type', 415);
    if (kind.ext === 'pdf' && pdfLooksUnsafe(buf)) return fail('rejected', 422);

    const name = safeFileName(decodeURIComponent(url.searchParams.get('name') || ''), kind.ext);
    const token = randomId(24);
    const uploads = await store(STORES.uploads);
    await uploads.setBuffer(token, buf, {
      metadata: { sid: session.sid, docId, name, size: buf.length, mime: kind.mime, createdAt: Date.now() },
    });
    return json({ ok: true, token, name, size: buf.length, type: kind.mime });
  } catch (e) {
    console.error('upload_failed', e?.message);
    return fail('server', 500);
  }
};
export const config = { path: '/api/upload' };
