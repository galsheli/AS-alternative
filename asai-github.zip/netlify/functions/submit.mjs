import { serverEnv } from '../../config/site.config.mjs';
import { SCHEMAS, pruneData, docsFor } from '../../public/js/schema.js';
import { validateAll } from '../../public/js/validators.js';
import { buildSummary } from '../../public/js/summary.js';
import { t } from '../../public/js/i18n/index.js';
import { store, STORES } from '../lib/storage.mjs';
import { json, fail, requireSession, sameOrigin, rateLimit, clientIp, sanitizeDeep, verifyTurnstile, oneLine } from '../lib/security.mjs';
import { nextReference } from '../lib/refs.mjs';
import { buildPdf, formatDateTime } from '../lib/pdf.mjs';
import { sendSubmissionMail } from '../lib/mail.mjs';
import { cfgNow, originOf, signFileLink } from '../lib/common.mjs';

const KEY_RE = /^[A-Za-z0-9_-]{16,64}$/;
const MIN_FILL_SECONDS = Number(process.env.MIN_SUBMIT_SECONDS ?? 8);

export default async (req) => {
  const env = serverEnv();
  let key;
  let stage = 'start';
  try {
    if (req.method !== 'POST') return fail('method', 405);
    if (!sameOrigin(req)) return fail('forbidden', 403);
    const session = requireSession(req);
    if (!session) return fail('session', 401);
    if (!(await rateLimit(req, 'submit', 60, 3600))) return fail('rate', 429);

    const raw = await req.text();
    if (raw.length > 1_000_000) return fail('size', 413);
    let body;
    try {
      body = JSON.parse(raw);
    } catch {
      return fail('bad_request', 400);
    }

    if (body.hp) return fail('bad_request', 400); // honeypot
    if (session.age < MIN_FILL_SECONDS * 1000) return fail('too_fast', 429);
    if (!(await verifyTurnstile(body.turnstile, clientIp(req)))) return fail('captcha', 400);

    key = String(body.submissionKey || '');
    if (!KEY_RE.test(key)) return fail('bad_request', 400);
    const type = body.type;
    if (!SCHEMAS[type]) return fail('bad_request', 400);
    const cfg = cfgNow();

    const idem = await store(STORES.idem);
    const metaStore = await store(STORES.meta);

    // ---- Idempotency: a repeated key never creates a second submission ----
    const claimed = await idem.setJSON(key, { status: 'processing', at: Date.now() }, { onlyIfNew: true });
    if (!claimed) {
      const rec = (await idem.getJSON(key)) || {};
      if (rec.status === 'emailed') return json({ ok: true, ref: rec.ref, duplicate: true });
      if (rec.status === 'processing' && Date.now() - rec.at < 60_000) return fail('busy', 409);
      if (rec.ref) {
        // stored earlier but e-mail not confirmed: retry delivery only
        await idem.setJSON(key, { ...rec, status: 'processing', at: Date.now() });
        stage = 'email';
        await deliver(rec.ref, req);
        await idem.setJSON(key, { ref: rec.ref, status: 'emailed', at: Date.now() });
        return json({ ok: true, ref: rec.ref });
      }
      await idem.setJSON(key, { status: 'processing', at: Date.now() });
    }

    // ---- Validate (server-side, authoritative) ----
    const data = pruneData(type, sanitizeDeep(body.data || {}), cfg);
    const uploads = await store(STORES.uploads);
    const files = {};
    for (const d of docsFor(type, data, cfg)) {
      const incoming = Array.isArray(body.files?.[d.id]) ? body.files[d.id].slice(0, d.max) : [];
      files[d.id] = [];
      for (const f of incoming) {
        const token = String(f?.token || '');
        if (!/^[A-Za-z0-9_-]{20,64}$/.test(token)) continue;
        const rec = await uploads.getBuffer(token);
        if (!rec || rec.metadata.sid !== session.sid || rec.metadata.docId !== d.id) continue;
        files[d.id].push({ token, name: rec.metadata.name, size: rec.metadata.size, type: rec.metadata.mime });
      }
    }
    const result = validateAll(type, data, files, cfg, body.declaration === true);
    if (!result.ok) {
      await idem.del(key);
      return fail('validation', 422, { fields: Object.keys(result.errors).slice(0, 60) });
    }

    // ---- Persist ----
    stage = 'persist';
    const schema = SCHEMAS[type];
    const submittedAt = new Date();
    const ref = await nextReference(cfg.refPrefix, submittedAt);
    const name = oneLine(schema.displayName(data));
    const flags = schema.flags(data);
    const contact = schema.contact(data);
    const sections = buildSummary(type, data, files, cfg);
    const docs = sections.find((s) => s.key === 'docs')?.blocks[0]?.rows.map((r) => ({ label: r.label, names: r.value.replace(/\n/g, ', ') })) || [];

    const dataStore = await store(STORES.data);
    await dataStore.setJSON(ref, { ref, type, data, files, submittedAt: submittedAt.toISOString(), dealName: cfg.dealName, currency: cfg.currency });
    stage = 'pdf';
    const pdf = await buildPdf({ type, ref, submittedAt, dealName: cfg.dealName, name, flags, sections });
    await (await store(STORES.pdf)).setBuffer(ref, pdf, { metadata: { ref, createdAt: Date.now() } });
    await metaStore.setJSON(ref, {
      ref, type, name, dealName: cfg.dealName, flags, contact: { email: oneLine(contact.email), phone: oneLine(contact.phone) },
      submittedAt: submittedAt.toISOString(), status: 'received', docs,
      tokens: Object.values(files).flat().map((f) => f.token),
    });
    const misc = await store(STORES.misc);
    for (const f of Object.values(files).flat()) await misc.setJSON(`used:${f.token}`, { ref });
    await idem.setJSON(key, { ref, status: 'received', at: Date.now() });

    // ---- Deliver e-mail (PDF attached) ----
    stage = 'email';
    await deliver(ref, req);
    await idem.setJSON(key, { ref, status: 'emailed', at: Date.now() });
    return json({ ok: true, ref });
  } catch (e) {
    console.error('submit_failed', e?.message); // never log form values
    // keep the idempotency record if data was already stored; otherwise release the key
    try {
      if (key) {
        const idem = await store(STORES.idem);
        const rec = await idem.getJSON(key);
        if (rec && !rec.ref) await idem.del(key);
        else if (rec) await idem.setJSON(key, { ...rec, status: 'received', at: Date.now() });
      }
    } catch {}
    const msg = String(e?.message || '');
    // Non-sensitive diagnostic code for support (never contains form data).
    const diag = stage === 'email' ? (msg.includes('SUBMISSION_EMAIL') ? 'no_recipient' : msg.includes('SMTP is not') ? 'no_smtp' : `smtp_${e?.code || 'error'}${e?.responseCode ? '_' + e.responseCode : ''}`) : stage;
    return fail('server', 500, { stage: diag });
  }
};

async function deliver(ref, req) {
  const env = serverEnv();
  const metaStore = await store(STORES.meta);
  const meta = await metaStore.getJSON(ref);
  const pdfRec = await (await store(STORES.pdf)).getBuffer(ref);
  const stored = await (await store(STORES.data)).getJSON(ref);
  if (!meta || !pdfRec || !stored) throw new Error('missing_submission');

  const origin = originOf(req);
  let links = [];
  if (env.emailFileLinks) {
    const cfg = cfgNow();
    const secs = buildSummary(meta.type, stored.data, stored.files, cfg);
    void secs;
    for (const [docId, list] of Object.entries(stored.files || {})) {
      for (const f of list) {
        const { exp, sig } = signFileLink(ref, f.token, env.fileLinkTtlHours);
        links.push({ label: `${t('d.' + docId)} – ${f.name}`, url: `${origin}/api/file?ref=${encodeURIComponent(ref)}&t=${f.token}&exp=${exp}&s=${sig}` });
      }
    }
  }
  const expiresText = formatDateTime(new Date(Date.now() + env.fileLinkTtlHours * 3600 * 1000)).split(' ')[0];
  await sendSubmissionMail({
    type: meta.type, name: meta.name, dealName: meta.dealName, ref,
    submittedAtText: formatDateTime(new Date(meta.submittedAt)),
    contact: meta.contact, flags: meta.flags, docs: meta.docs, links, expiresText, pdf: pdfRec.data,
  });
  await metaStore.setJSON(ref, { ...meta, status: 'emailed', emailedAt: new Date().toISOString() });
}

export const config = { path: '/api/submit' };
