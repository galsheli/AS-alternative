import { store, STORES } from '../lib/storage.mjs';
import { fail, rateLimit } from '../lib/security.mjs';
import { verifyFileLink } from '../lib/common.mjs';

// Signed, expiring download link for internal staff (sent in the notification e-mail).
export default async (req) => {
  try {
    if (req.method !== 'GET') return fail('method', 405);
    if (!(await rateLimit(req, 'file', 120, 3600))) return fail('rate', 429);
    const u = new URL(req.url);
    const ref = u.searchParams.get('ref');
    const token = u.searchParams.get('t');
    if (!verifyFileLink(ref, token, u.searchParams.get('exp'), u.searchParams.get('s'))) return fail('expired', 403);
    const rec = await (await store(STORES.uploads)).getBuffer(token);
    if (!rec) return fail('not_found', 404);
    const fname = encodeURIComponent(rec.metadata.name || 'document');
    return new Response(rec.data, {
      status: 200,
      headers: {
        'Content-Type': rec.metadata.mime || 'application/octet-stream',
        'Content-Disposition': `attachment; filename*=UTF-8''${fname}`,
        'Cache-Control': 'private, no-store',
        'X-Content-Type-Options': 'nosniff',
        'X-Robots-Tag': 'noindex, nofollow',
        'Content-Security-Policy': "default-src 'none'; sandbox",
      },
    });
  } catch (e) {
    console.error('file_failed', e?.message);
    return fail('server', 500);
  }
};
export const config = { path: '/api/file' };
