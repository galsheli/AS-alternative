import { publicConfig } from '../../config/site.config.mjs';
import { issueSession, json, rateLimit, fail } from '../lib/security.mjs';

// Bootstraps the SPA: public configuration + a fresh signed session token.
export default async (req) => {
  if (req.method !== 'GET') return fail('method', 405);
  // Rate limiting must never take the whole form down: if storage is unavailable, log and continue.
  try {
    if (!(await rateLimit(req, 'init', 120, 3600))) return fail('rate', 429);
  } catch (e) {
    console.error('init_ratelimit_unavailable:', e?.message);
  }
  try {
    const { token } = issueSession();
    return json({ ok: true, config: publicConfig(), session: token });
  } catch (e) {
    // Most common cause: SESSION_SECRET missing/too short (needs >= 32 characters).
    console.error('init_failed:', e?.message);
    return fail('server_config', 500);
  }
};
export const config = { path: '/api/init' };
