// Central, editable settings. Values can be overridden with environment variables
// (Netlify UI -> Site configuration -> Environment variables) without touching code.
// Anything listed under `publicConfig()` is sent to the browser; everything else stays server-side.

const env = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : d);
const bool = (v, d) => (v === undefined ? d : ['1', 'true', 'yes'].includes(String(v).toLowerCase()));

export function getConfig() {
  return {
    // ----- Brand (derived from the Altshuler Shaham logo) -----
    brand: {
      name: 'אלטשולר שחם השקעות אלטרנטיביות',
      logo: '/assets/logo.png',
      logoMark: '/assets/logo-mark.png',
      colors: {
        '--green-900': env('BRAND_GREEN_DARK', '#06613D'),
        '--green-700': env('BRAND_GREEN', '#008050'),
        '--orange-500': env('BRAND_ORANGE', '#F07020'),
      },
    },

    // ----- Deal / product -----
    dealName: env('DEAL_NAME', 'TEST'),
    currency: env('INVESTMENT_CURRENCY', 'USD'), // ISO code shown next to the amount
    refPrefix: env('REF_PREFIX', 'ASAI'),

    // ----- Editable wording (leave undefined to use i18n/he.js defaults) -----
    texts: {
      introTitle: env('TEXT_INTRO_TITLE'),
      introLead: env('TEXT_INTRO_LEAD'),
      privacyNote: env('TEXT_PRIVACY_NOTE'),
      declaration: env('TEXT_DECLARATION'),
      successTitle: env('TEXT_SUCCESS_TITLE'),
      successText: env('TEXT_SUCCESS_TEXT'),
    },

    // ----- Eligibility clauses (סעיף הכשירות). Empty => free-text field.
    // Fill with the clauses of the eligibility declaration, e.g. [{ value: 'a', label: 'סעיף א' }]
    eligibilityOptions: safeJson(env('ELIGIBILITY_OPTIONS_JSON'), []),

    // ----- Field / document requirements -----
    // fieldOverrides: { 'inv_swift': { required: true }, 'crs.tin': { required: true } }
    fieldOverrides: safeJson(env('FIELD_OVERRIDES_JSON'), {}),
    // docOverrides: { 'doc_eligibility': { required: false } }
    docOverrides: safeJson(env('DOC_OVERRIDES_JSON'), {}),

    // ----- Corporate W-9 flow -----
    w9AllowLater: bool(env('W9_ALLOW_LATER'), true),

    // ----- Uploads -----
    // Netlify Functions accept ~6MB request bodies, so keep <= 4.5. Images are auto-compressed client-side.
    maxFileMB: Number(env('MAX_FILE_MB', '4')),

    // ----- Save & continue -----
    resumeDays: Number(env('RESUME_DAYS', '7')),
    enableResume: bool(env('ENABLE_RESUME'), true),

    // ----- Bot protection (optional Cloudflare Turnstile) -----
    turnstileSiteKey: env('TURNSTILE_SITE_KEY', ''),
  };
}

export function publicConfig() {
  const c = getConfig();
  return c; // nothing in getConfig() is secret; secrets are read separately via serverEnv()
}

// Server-only values (never sent to the browser).
export function serverEnv() {
  return {
    submissionEmail: env('SUBMISSION_EMAIL', ''),
    mailFrom: env('MAIL_FROM', ''),
    smtp: {
      host: env('SMTP_HOST', ''),
      port: Number(env('SMTP_PORT', '587')),
      secure: bool(env('SMTP_SECURE'), false),
      user: env('SMTP_USER', ''),
      pass: env('SMTP_PASS', ''),
    },
    secret: env('SESSION_SECRET', ''),
    turnstileSecret: env('TURNSTILE_SECRET', ''),
    fileLinkTtlHours: Number(env('FILE_LINK_TTL_HOURS', '168')),
    emailFileLinks: bool(env('EMAIL_FILE_LINKS'), true),
    retention: {
      uploadsDays: Number(env('RETENTION_UPLOADS_DAYS', '0')), // 0 = keep
      submissionsDays: Number(env('RETENTION_SUBMISSIONS_DAYS', '0')),
    },
    isLocal: env('LOCAL_DEV', '') === '1',
    siteUrl: env('URL', ''),
  };
}

function safeJson(s, d) {
  if (!s) return d;
  try {
    return JSON.parse(s);
  } catch {
    return d;
  }
}
