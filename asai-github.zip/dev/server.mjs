// Local development server (no Netlify CLI needed): static files + the same function handlers.
// Usage: LOCAL_DEV=1 SUBMISSION_EMAIL=test@example.com node dev/server.mjs
process.env.LOCAL_DEV ||= '1';
process.env.SUBMISSION_EMAIL ||= 'asalternative@altshul.co.il';
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fnDir = path.join(root, 'netlify/functions');
const names = ['init', 'upload', 'submit', 'file', 'resume'];
const routes = {};
for (const n of names) {
  const m = await import(`${fnDir}/${n}.mjs`);
  routes[m.config.path] = m.default;
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.woff2': 'font/woff2', '.json': 'application/json' };

export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const fn = routes[url.pathname];
      if (fn) {
        const chunks = [];
        for await (const c of req) chunks.push(c);
        const body = chunks.length ? Buffer.concat(chunks) : undefined;
        const r = await fn(new Request(url, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body }));
        res.writeHead(r.status, Object.fromEntries(r.headers));
        return res.end(Buffer.from(await r.arrayBuffer()));
      }
      let p = url.pathname === '/' ? '/index.html' : url.pathname;
      const file = path.join(root, 'public', path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
      if (!file.startsWith(path.join(root, 'public'))) throw new Error('nope');
      const data = await readFile(file);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    } catch {
      res.writeHead(404).end('not found');
    }
  });
}
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 8888);
  createServer().listen(port, () => console.log(`http://localhost:${port}`));
}
