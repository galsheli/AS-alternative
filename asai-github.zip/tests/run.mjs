// End-to-end tests against the real function handlers (local storage + local outbox).
process.env.LOCAL_DEV = '1';
process.env.RATE_LIMIT_OFF = '1';
process.env.MIN_SUBMIT_SECONDS = '0';
process.env.SUBMISSION_EMAIL = 'asalternative@altshul.co.il';
process.env.LOCAL_BLOBS_DIR = '.local/test-blobs';
process.env.DEAL_NAME = 'קרן בדיקה אלפא';
process.env.INVESTMENT_CURRENCY = 'USD';
import { rmSync, readFileSync, readdirSync, writeFileSync, mkdirSync } from 'node:fs';
import assert from 'node:assert/strict';
rmSync('.local', { recursive: true, force: true });

const load = async (n) => (await import(`../netlify/functions/${n}.mjs`)).default;
const [init, upload, submit, fileFn, resume] = await Promise.all(['init', 'upload', 'submit', 'file', 'resume'].map(load));
const { validateAll, validIban, validIsraeliId, validEmail } = await import('../public/js/validators.js');
const { initialData } = await import('../public/js/schema.js');
const { getConfig } = await import('../config/site.config.mjs');
const cfg = getConfig();

let pass = 0, failN = 0;
const test = async (name, fn) => {
  try { await fn(); pass++; console.log('  ✓', name); } catch (e) { failN++; console.log('  ✗', name, '\n    ', e.message); }
};
const H = (extra = {}) => ({ host: 'localhost', ...extra });
const call = (fn, path, { method = 'POST', session, body, headers = {} } = {}) =>
  fn(new Request('http://localhost' + path, { method, headers: { host: 'localhost', ...(session ? { 'x-asai-session': session } : {}), ...headers }, body }));
const j = async (r) => ({ status: r.status, ...(await r.json()) });

const PDF = Buffer.from('%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<<>>\n%%EOF\n');
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(200, 1)]);
const JPG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(200, 2)]);

async function newSession() { const r = await j(await call(init, '/api/init', { method: 'GET' })); return r.session; }
async function up(session, doc, buf, name = 'scan.pdf') {
  const r = await j(await call(upload, `/api/upload?doc=${doc}&name=${encodeURIComponent(name)}`, { session, body: buf, headers: { 'content-type': 'application/octet-stream' } }));
  return r;
}
async function upAll(session, docs) {
  const files = {};
  for (const d of docs) { const r = await up(session, d, d.includes('id') || d.includes('Id') ? PNG : PDF, 'מסמך-' + d + (d.includes('id') ? '.png' : '.pdf')); assert.equal(r.ok, true, 'upload ' + d); files[d] = [{ token: r.token }]; }
  return files;
}
let n = 0;
const key = () => 'key_' + (++n) + '_abcdefghijklmnop';
const send = async (session, payload) => j(await call(submit, '/api/submit', { session, body: JSON.stringify({ submissionKey: key(), declaration: true, ...payload }) }));

const indBase = () => ({
  ...initialData('individual'),
  firstNameEn: 'Dana', lastNameEn: 'Levi', firstNameHe: 'דנה', lastNameHe: 'לוי', email: 'dana@example.com',
  idType: 'id', idNumber: '000000018', birthDate: '1985-04-12', phone: '0501234567',
  address: 'הרצל 10', city: 'תל אביב', country: 'IL', postalCode: '6100000', birthCountry: 'IL', amount: '250000', eligibility: 'סעיף ג',
  inv_bankName: 'בנק לאומי', inv_bankNumber: '10', inv_branch: '800', inv_account: '123456', inv_iban: 'IL620108000000099999999', inv_swift: 'LUMIILIT', inv_bankAddress: 'יהודה הלוי 34 תל אביב',
  paymentSame: 'yes',
  occupationType: 'employee', jobTitle: 'מנהלת כספים בחברת היי-טק', ownsBusiness: 'no', fundsSource: ['salary', 'savings'],
  foreignActivity: 'no', residency: 'israel', pep: 'no', fatcaUS: 'no',
  crs: [{ country: 'IL', tin: '000000018' }],
});

console.log('Unit');
await test('IBAN checksum', () => { assert.ok(validIban('IL62 0108 0000 0009 9999 999')); assert.ok(!validIban('IL62 0108 0000 0009 9999 998')); });
await test('Israeli ID checksum', () => { assert.ok(validIsraeliId('000000018')); assert.ok(!validIsraeliId('123456789')); });
await test('email validation', () => { assert.ok(validEmail('a@b.co')); assert.ok(!validEmail('a@b')); assert.ok(!validEmail('a b@c.com')); });

console.log('Validation (Hebrew error keys)');
await test('missing required fields', () => {
  const r = validateAll('individual', initialData('individual'), {}, cfg);
  assert.equal(r.ok, false); assert.equal(r.errors.firstNameEn, 'e.required'); assert.equal(r.errors.idType, 'e.choose'); assert.equal(r.errors['doc.doc_id'], 'e.doc');
});
await test('invalid email flagged', () => {
  const r = validateAll('individual', { ...indBase(), email: 'nope' }, {}, cfg); assert.equal(r.errors.email, 'e.email');
});
await test('CRS: no TIN requires reason; "cannot provide" requires explanation', () => {
  let d = { ...indBase(), crs: [{ country: 'US', tin: '' }] };
  assert.equal(validateAll('individual', d, {}, cfg).errors['crs.0.tinReason'], 'e.choose');
  d = { ...indBase(), crs: [{ country: 'US', tin: '', tinReason: 'cannotProvide' }] };
  assert.equal(validateAll('individual', d, {}, cfg).errors['crs.0.tinExplain'], 'e.required');
  d = { ...indBase(), crs: [{ country: 'US', tin: '', tinReason: 'noIssue' }] };
  assert.equal(validateAll('individual', d, {}, cfg).errors['crs.0.tinExplain'], undefined);
});
await test('conditional fields only required when visible', () => {
  const e1 = validateAll('individual', { ...indBase(), foreignActivity: 'yes' }, {}, cfg).errors;
  assert.equal(e1.foreignActivityType, 'e.required'); assert.equal(e1.foreignActivityCountry, 'e.choose');
  const e2 = validateAll('individual', { ...indBase(), residency: 'foreign' }, {}, cfg).errors; assert.equal(e2.israelTie, 'e.choose');
  const e3 = validateAll('individual', { ...indBase(), paymentSame: 'no' }, {}, cfg).errors; assert.equal(e3.pay_bankName, 'e.required'); assert.equal(e3['doc.doc_bankPay'], 'e.doc');
});

console.log('API');
await test('upload: wrong file type rejected', async () => {
  const s = await newSession(); const r = await up(s, 'doc_id', Buffer.from('MZ\x90\x00 executable'), 'evil.pdf'); assert.equal(r.ok, false); assert.equal(r.status, 415);
});
await test('upload: PDF with JavaScript rejected', async () => {
  const s = await newSession(); const r = await up(s, 'doc_id', Buffer.from('%PDF-1.4\n/JavaScript (app.alert(1))\n'), 'x.pdf'); assert.equal(r.status, 422);
});
await test('upload: oversize rejected', async () => {
  const s = await newSession(); const r = await up(s, 'doc_id', Buffer.concat([PDF, Buffer.alloc(5 * 1024 * 1024)]), 'big.pdf'); assert.equal(r.status, 413);
});
await test('upload: no session rejected', async () => {
  const r = await j(await call(upload, '/api/upload?doc=doc_id', { body: PDF })); assert.equal(r.status, 401);
});
await test('cross-site request rejected (CSRF)', async () => {
  const s = await newSession();
  const r = await j(await call(upload, '/api/upload?doc=doc_id', { session: s, body: PDF, headers: { 'sec-fetch-site': 'cross-site' } })); assert.equal(r.status, 403);
});

let ref1;
await test('Individual – Israeli: full submission, PDF + e-mail', async () => {
  const s = await newSession();
  const files = await upAll(s, ['doc_id', 'doc_address', 'doc_bank', 'doc_eligibility']);
  const r = await send(s, { type: 'individual', data: indBase(), files });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.match(r.ref, /^ASAI-\d{4}-\d{6}$/); ref1 = r.ref;
});
await test('e-mail: recipient from env, subject format, PDF attached, no plaintext ID docs', () => {
  const eml = readFileSync(`.local/outbox/${ref1}.eml`, 'utf8');
  assert.match(eml, /To: asalternative@altshul\.co\.il/);
  assert.match(eml, /application\/pdf/);
  const subj = /Subject: (.*)/.exec(eml)[1]; assert.ok(subj.includes('=?UTF-8?'), subj);
  assert.ok(eml.includes(ref1));
});
await test('PDF is valid, branded, multi-font (sanity)', async () => {
  const stored = readFileSync(`.local/test-blobs/submissions-pdf/${ref1}`);
  assert.equal(stored.subarray(0, 5).toString(), '%PDF-'); assert.ok(stored.length > 20000);
  mkdirSync('.local/out', { recursive: true }); writeFileSync('.local/out/individual.pdf', stored);
});
await test('duplicate submissionKey never creates a 2nd submission', async () => {
  const s = await newSession(); const files = await upAll(s, ['doc_id', 'doc_address', 'doc_bank', 'doc_eligibility']);
  const k = key(); const body = JSON.stringify({ submissionKey: k, declaration: true, type: 'individual', data: indBase(), files });
  const a = await j(await call(submit, '/api/submit', { session: s, body })); const b = await j(await call(submit, '/api/submit', { session: s, body }));
  assert.equal(a.ref, b.ref); assert.equal(b.duplicate, true);
});
await test('server rejects missing declaration & invalid data (no data leak)', async () => {
  const s = await newSession(); const files = await upAll(s, ['doc_id', 'doc_address', 'doc_bank', 'doc_eligibility']);
  const r = await j(await call(submit, '/api/submit', { session: s, body: JSON.stringify({ submissionKey: key(), declaration: false, type: 'individual', data: indBase(), files }) }));
  assert.equal(r.status, 422); assert.ok(r.fields.includes('declaration'));
});
await test('server rejects another session\'s upload tokens', async () => {
  const s1 = await newSession(); const s2 = await newSession(); const files = await upAll(s1, ['doc_id', 'doc_address', 'doc_bank', 'doc_eligibility']);
  const r = await send(s2, { type: 'individual', data: indBase(), files }); assert.equal(r.status, 422);
});
await test('Individual – foreign resident, passport, foreign CRS/TIN, different payment bank', async () => {
  const s = await newSession();
  const files = await upAll(s, ['doc_id', 'doc_address', 'doc_bank', 'doc_bankPay', 'doc_eligibility']);
  const d = { ...indBase(), idType: 'passport', idNumber: 'X1234567', country: 'FR', city: 'Paris', address: '12 Rue de Rivoli', postalCode: '75001', phone: '+33 1 23 45 67 89',
    residency: 'foreign', israelTie: 'relatives', foreignActivity: 'yes', foreignActivityType: 'השקעות נדל"ן', foreignActivityCountry: 'FR',
    paymentSame: 'no', pay_bankName: 'BNP Paribas', pay_account: '00012345678', pay_iban: 'FR1420041010050500013M02606', pay_bankAddress: '16 Boulevard des Italiens, 75009 Paris',
    pep: 'yes', pepDetails: 'קרוב משפחה חבר פרלמנט לשעבר', crs: [{ country: 'FR', tin: '1234567890123' }, { country: 'IL', tin: '', tinReason: 'noIssue' }] };
  const r = await send(s, { type: 'individual', data: d, files }); assert.equal(r.ok, true, JSON.stringify(r));
  const meta = JSON.parse(readFileSync(`.local/test-blobs/submissions-meta/${r.ref}`, 'utf8')); assert.deepEqual(meta.flags, ['pep']);
  writeFileSync('.local/out/foreign.pdf', readFileSync(`.local/test-blobs/submissions-pdf/${r.ref}`));
});
const corpBase = () => ({
  ...initialData('corporate'), corpNameHe: 'חברת בדיקות בע"מ', corpNameEn: 'Test Holdings Ltd', regNumber: '515000000', incDate: '2015-06-01', corpPhone: '03-5555555',
  address: 'רוטשילד 1', city: 'תל אביב', country: 'IL', postalCode: '6688101', incCountry: 'IL',
  signatories: [{ nameEn: 'Avi Cohen', nameHe: 'אבי כהן', phone: '0521111111', email: 'avi@test.co.il', idNumber: '000000018', role: 'מנכ"ל' }, { nameEn: 'Ron Bar', nameHe: 'רון בר', phone: '0522222222', email: 'ron@test.co.il', idNumber: '000000026', role: 'סמנכ"ל כספים' }],
  contactIsSignatory: 'yes', contactSignatory: '1',
  corpType: 'private', corpField: 'נדל"ן', fundsSource: ['businessReceipts'], foreignActivity: 'no', pep: 'no',
  inv_bankName: 'בנק הפועלים', inv_account: '555111', inv_iban: 'IL620108000000099999999', inv_bankAddress: 'שדרות רוטשילד 50, תל אביב', paymentSame: 'yes', usEntity: 'no',
});
const corpDocs = ['doc_incorporation', 'doc_signatoryProtocol', 'doc_registryExtract', 'doc_controllersId', 'doc_bank', 'doc_corpAddress', 'doc_eligibility'];
await test('Corporate: 2 signatories, contact chosen from signatories, all docs', async () => {
  const s = await newSession(); const files = await upAll(s, corpDocs);
  const r = await send(s, { type: 'corporate', data: corpBase(), files }); assert.equal(r.ok, true, JSON.stringify(r));
  const meta = JSON.parse(readFileSync(`.local/test-blobs/submissions-meta/${r.ref}`, 'utf8')); assert.equal(meta.contact.email, 'ron@test.co.il');
  writeFileSync('.local/out/corporate.pdf', readFileSync(`.local/test-blobs/submissions-pdf/${r.ref}`));
});
await test('Corporate US entity: W-9 later flags; W-9 now requires upload', async () => {
  const s = await newSession();
  const d = { ...corpBase(), usEntity: 'yes', w9Mode: 'later' };
  const r = await send(s, { type: 'corporate', data: d, files: await upAll(s, corpDocs) }); assert.equal(r.ok, true, JSON.stringify(r));
  const meta = JSON.parse(readFileSync(`.local/test-blobs/submissions-meta/${r.ref}`, 'utf8')); assert.deepEqual(meta.flags, ['usEntity', 'w9Later']);
  const e = validateAll('corporate', { ...d, w9Mode: 'now' }, {}, cfg).errors; assert.equal(e['doc.doc_w9'], 'e.doc');
});
await test('Corporate: contact not signatory requires own details', () => {
  const e = validateAll('corporate', { ...corpBase(), contactIsSignatory: 'no' }, {}, cfg).errors; assert.equal(e.contactNameHe, 'e.required'); assert.equal(e.contactEmail, 'e.required');
});
await test('Signed file link works, tampered/expired rejected', async () => {
  const eml = readFileSync(`.local/outbox/${ref1}.eml`, 'utf8').replace(/=\r?\n/g, '');
  const m = /\/api\/file\?ref=[^\s"<>]+/.exec(eml.replace(/=3D/g, '=').replace(/=26/g, '&'));
  assert.ok(m, 'link in email'); const ok = await call(fileFn, m[0].replace(/&amp;/g, '&'), { method: 'GET' }); assert.equal(ok.status, 200);
  assert.equal((await call(fileFn, m[0].replace(/&amp;/g, '&').replace(/s=(.)/, 's=Z'), { method: 'GET' })).status, 403);
});
await test('Save & resume: encrypted draft round-trip', async () => {
  const s = await newSession(); const data = { ...indBase() };
  const sv = await j(await call(resume, '/api/resume', { session: s, body: JSON.stringify({ action: 'save', type: 'individual', data, files: {}, stepIndex: 3 }) })); assert.ok(sv.token);
  const dir = readdirSync('.local/test-blobs/drafts').filter((x) => !x.endsWith('.meta'));
  assert.ok(!readFileSync('.local/test-blobs/drafts/' + dir[0]).includes('dana@example.com'), 'draft must be encrypted');
  const ld = await j(await call(resume, '/api/resume', { body: JSON.stringify({ action: 'load', token: sv.token }) })); assert.equal(ld.data.email, 'dana@example.com'); assert.ok(ld.session);
  assert.equal((await j(await call(resume, '/api/resume', { body: JSON.stringify({ action: 'load', token: 'x'.repeat(43) }) }))).status, 404);
});
await test('honeypot & fast-bot blocked', async () => {
  const s = await newSession(); const r = await j(await call(submit, '/api/submit', { session: s, body: JSON.stringify({ hp: 'bot', submissionKey: key(), type: 'individual', data: {} }) })); assert.equal(r.status, 400);
});
console.log(`\n${pass} passed, ${failN} failed`);
process.exit(failN ? 1 : 0);
